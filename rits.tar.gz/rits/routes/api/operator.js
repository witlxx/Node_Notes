"use stirct";

const Router = require("koa-router");
const optRoute = new Router();
const koaBody = require("koa-body");
const { userController } = require("../../controller");

optRoute.post(
  "/csv",
  koaBody({
    multipart: true,
    formidable: { maxFieldsSize: 10 * 1024 * 1024, multipart: true }
  }),
  userController.csvUser
);
optRoute.post("/", userController.postUser);
optRoute.delete("/:suid", userController.deleteUser);
optRoute.put("/:suid", userController.putUser);
optRoute.get("/count", userController.countUsers);
optRoute.get("/", userController.getUsers);

module.exports = optRoute;
