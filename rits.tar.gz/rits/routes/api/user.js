"use stirct";
const Router = require("koa-router");
const userRoute = new Router();
const koaBody = require("koa-body");
const { userController, docController } = require("../../controller");

userRoute.post("/login", userController.userLogin);
userRoute.post("/pass", userController.postMailer);
userRoute.post("/docs/:type", docController.getMyDocs);
userRoute.post("/countDoc/:type", docController.countMyDocs);
userRoute.post(
  "/avatar",
  koaBody({
    multipart: true,
    formidable: { maxFieldsSize: 10 * 1024 * 1024, multipart: true }
  }),
  userController.postAvatar
);
userRoute.put("/passwd", userController.modifyPass);
userRoute.put("/own", userController.putOneUser);
userRoute.get("/", userController.getOneUser);
userRoute.get("/agents", userController.agents);
userRoute.get("/dept/:deptId", userController.getUsersInDept);

module.exports = userRoute;
