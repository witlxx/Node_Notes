"use stirct";

const Router = require("koa-router");
const ruleRoute = new Router();
const { ruleController } = require("../../controller");

ruleRoute.post("/", ruleController.postRule);
ruleRoute.delete("/:ruleHashId", ruleController.deleteRule);
ruleRoute.put("/:ruleHashId", ruleController.putRule);
ruleRoute.get("/", ruleController.getRules);
ruleRoute.get("/count", ruleController.countRules);

module.exports = ruleRoute;
