"use stirct";
const Router = require("koa-router");
const koaBody = require("koa-body");
const deptRoute = new Router();
const { deptController } = require("../../controller");

deptRoute.post(
  "/csv",
  koaBody({
    multipart: true,
    formidable: { maxFieldsSize: 10 * 1024 * 1024, multipart: true }
  }),
  deptController.csvDept
);
deptRoute.post("/", deptController.postDept);
deptRoute.delete("/:deptId", deptController.deleteDept);
deptRoute.put("/:deptId", deptController.putDept);
deptRoute.get("/", deptController.getDepts);
deptRoute.get("/count", deptController.countDepts);
deptRoute.get("/child", deptController.treeDepts);

module.exports = deptRoute;
