"use stirct";

const Router = require("koa-router");
const systemRoute = new Router();
const { systemController } = require("../../controller");

systemRoute.post("/", systemController.postSystemSet);
systemRoute.post("/vertify", systemController.vertify);
systemRoute.get("/", systemController.getSystemSet);

module.exports = systemRoute;
