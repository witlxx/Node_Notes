"use stirct";

const Router = require("koa-router");
const docRoute = new Router();
const { docController, ruleController } = require("../../controller");
const { auth } = require("../../middlewares");
const koaBody = require("koa-body");

docRoute.post("/", docController.createDoc);
docRoute.post("/count", docController.countDocs);
docRoute.post("/docs", docController.getDocs);
docRoute.post(
  "/upload",
  koaBody({
    multipart: true,
    formidable: { maxFieldsSize: 10 * 1024 * 1024, multipart: true }
  }),
  docController.uploadDoc
);
docRoute.post("/download", docController.downloadDoc);
docRoute.post("/process", ruleController.matchProcess);
docRoute.post("/ignite", auth.sameUser, ruleController.igniteProcess);
docRoute.post("/:docId/:type", ruleController.resOptProcess);
docRoute.delete("/:docId", auth.admin, docController.deleteDoc);
docRoute.put("/:docId", auth.sameUser, docController.updateDoc);
docRoute.get("/tags", docController.getTags);
docRoute.get("/signatory", docController.getSignatory);
docRoute.get("/queryDept", docController.queryDept);
docRoute.get("/:docId/records/:type", docController.fectchRecords);

module.exports = docRoute;
