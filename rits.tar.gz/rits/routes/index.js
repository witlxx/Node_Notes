"use strict";
const Router = require("koa-router");
const fs = require("fs");
const router = new Router();
const jsonwebtoken = require("jsonwebtoken");
const FError = require("../util/FError");
const { FEnum } = require("../util");
const config = require(process.env.config);

module.exports = app => {
  /**路由分发 */
  let apis = fs.readdirSync(__dirname + "/api");
  apis.forEach(element => {
    let module = require(__dirname + "/api/" + element);
    router.use(
      "/" + element.replace(".js", ""),
      module.routes(),
      module.allowedMethods()
    );
  });

  app.use(async (ctx, next) => {
    const token = ctx.headers["token"];
    let path = (ctx.request.path || "").split("?"),
      body;
    const whiteLists = ["/user/login", "/user/pass"];
    const white = whiteLists.filter(white => white === path[0]).length !== 0;
    const immune = immuneHandler(path[0], ctx.request);
    if (!white && !immune) {
      if (!token) {
        ctx.throw(400, FError.InvalidParameters("missing token argument"));
      }
      body = jsonwebtoken.verify(token, config.aeskey.secret);
      if (!body || body == {}) {
        ctx.throw(404, FError.NotFoundUser("no user found"));
      }
      const isAdmin = body.data.isAdmin;
      const apis = ["operator", "dept", "rule", "system"];
      path = path.length > 1 ? path[0].split("/") : [""];
      const admin = apis.filter(mod => mod === path[1]);
      if (admin.length > 0 && !isAdmin) {
        ctx.throw(403, FError.InvalidAdmin("invalid admin parameters"));
      }
      ctx.request.user = body.data;
    }
    await next();
  });

  app.use(router.routes());
};

function immuneHandler(api, req) {
  switch (api) {
    case "/user/passwd":
      if (req.body.type === FEnum.PassUpdMethod.email) return true;
    default:
      return false;
  }
}
