#!/bin/sh

#PRO_MONGO_URL
#PRO_REDIS_PORT
#PRO_REDIS_HOST
#PRO_ES_URL
#DOC_ES_INDEX

write_config() {
cat <<EOF >config/config.js
module.exports = {
  mongo: "${PRO_MONGO_URL}",
  domain: "",
  redis: {
    port: ${PRO_REDIS_PORT},
    host: "${PRO_REDIS_HOST}",
    db: 0,
    password: ""
  },
  rootDept: {
    level: 1
  },
  es: {
    host: "${PRO_ES_URL}"
  },
  docESIndex: "${DOC_ES_INDEX}",
  aeskey: {
    secret: "41b76a42-be3b-4805-abdc-2f63e8442ced",
    smb: {
      key: "e57eaa40-b80d-11e9-8ba5-873ea42bb849",
      iv: "f13e5330-b80d-11e9-8ba5-873ea42bb849"
    }
  }
};
EOF

echo ">>> write config.js"
cat config/config.js
echo ">>> write config.js end"
}

rm -rf config && mkdir config && chmod 777 ./config
write_config
