"use strict";

const mongoose = require("mongoose");
const BaseModel = require("./extends");
const Schema = mongoose.Schema;

/**
 * @class RuleSchema
 * @memberOf module:FModel
 * @constructor
 * @mixes Document
 * @property {String} name 规则名称
 * @property {<Module: FEnum.DocumentCategory>} category
 * @property {<Module: Schema.Types.Mixed>} auditPath
 * @property {<Module: Schema.Types.Mixed>} sealPath
 * @property {String} ruleHashId
 * @property {Date} createTime 创建时间
 */
const RuleSchema = new Schema({
  name: { type: String, required: true },
  category: { type: Number, required: true, unique: true },
  auditPath: { type: Schema.Types.Mixed, required: true },
  sealPath: { type: Schema.Types.Mixed, required: true },
  createTime: { type: Date, required: true, default: Date.now },
  ruleHashId: { type: String }
});

RuleSchema.index(
  { ruleHashId: 1 },
  { partialFilterExpression: { ruleHashId: { $exists: true } } }
);

RuleSchema.plugin(BaseModel);
mongoose.model("Rule", RuleSchema);
