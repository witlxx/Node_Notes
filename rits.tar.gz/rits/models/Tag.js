"use strict";

const mongoose = require("mongoose");
const BaseModel = require("./extends");
const Schema = mongoose.Schema;

/**
 * @class TagtSchema
 * @memberOf module:FModel
 * @constructor
 * @mixes Document
 * @property
 */
const TagtSchema = new Schema({
  name: { type: String, required: true }
});

TagtSchema.plugin(BaseModel);

mongoose.model("Tag", TagtSchema);
