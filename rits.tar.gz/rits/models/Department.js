"use strict";

const mongoose = require("mongoose");
const BaseModel = require("./extends");
const Schema = mongoose.Schema;

/**
 * @class DepartmentSchema
 * @memberOf module:FModel
 * @constructor
 * @mixes Document
 * @property {ObjectId} _id deptId 部门唯一标识
 * @property {String} parentId 当前部门的父级部门
 * @property {String} name 部门名称
 * @property {String} referred 部门简称
 * @property {module:<FEnum.DeptLevel>} level 部门职级
 * @property {String} description 部门简介
 * @property {Boolean} isLeaf 是否是叶子节点(当下该部门树的最后节点)
 * @property {Date} createTime 部门创建时间
 * @property {Boolean} isSealDept 是否是只管理盖章的中心(如: bsc中心)
 */
const DepartmentSchema = new Schema({
  parentId: { type: Schema.ObjectId },
  name: { type: String, required: true },
  referred: { type: String, required: true },
  level: { type: Number, required: true },
  description: { type: String },
  isLeaf: { type: Boolean, default: true },
  createTime: { type: Date, required: true, default: Date.now },
  isSealDept: { type: Boolean, default: false }
});

DepartmentSchema.index(
  { parentId: 1 },
  { partialFilterExpression: { parentId: { $exists: true } } }
);
DepartmentSchema.index({ name: 1 }, { unique: true });
DepartmentSchema.index({ referred: 1 }, { unique: true });
DepartmentSchema.index({ name: 1, referred: 1 });
DepartmentSchema.plugin(BaseModel);

mongoose.model("Department", DepartmentSchema);
