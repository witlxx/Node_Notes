"use strict";

const mongoose = require("mongoose");
const BaseModel = require("./extends");
const Schema = mongoose.Schema;

/**
 * @class SystemSetSchema
 * @memberOf module:FModel
 * @constructor
 * @mixes Document
 * @property {<Moudle: FEnum.SystemSetType>} setType 设定的类型(如: "storage set"| "mail set")
 * @property {String} setType name下的分类,如邮件设定(smb | sharePoint)
 * @property {Schema.Types.Mixed} content 系统设定的内容
 */
const SystemSetSchema = new Schema({
  setType: { type: Number, required: true },
  type: { type: Number },
  content: { type: Schema.Types.Mixed }
});

SystemSetSchema.plugin(BaseModel);

mongoose.model("SystemSet", SystemSetSchema);
