"use strict";

const mongoose = require("mongoose");
const BaseModel = require("./extends");
const Schema = mongoose.Schema;
const { FEnum } = require("../util");

/**
 * @class DocumentSchema
 * @memberOf module:FModel
 * @constructor
 * @mixes Document
 * @property {ObjectId} _id docId
 * @property {String} name 文档名称
 * @property {ObjectId} uid 创建者uid
 * @property {ObjectId} deptId 创建者uid所在的根部门下一级部门deptId
 * @property {<Module: FEnum.DocumentCategory>} category 文档类别
 * @property {<Module: FEnum.DocumentType>} type 文档类型
 * @property {Date} createTime 创建时间
 * @property {Date} updateTime 文档更新时间
 * @property {Date} startTime 合同期间起点
 * @property {Date} endTime 合同期间终点
 * @property {Boolean} format 是否为格式合同
 * @property {String} decisiveNo d/f可决号
 * @property {String} decisiveLink d/f可决链接
 * @property {Number} contractMoney 合同金额
 * @property {Number} applyMoney 申请金额
 * @property {<Module: FEnum.CurrencyUnit>} currencyUnit 货币单位
 * @property {Number} copies 份数
 * @property {Number} pages 页数
 * @property {String} description 文档说明
 * @property {<FEnum.DocumentState>} state 文档状态
 * @property {Boolean} pagingSeal 是否加盖骑缝章
 * @property {[<Module: FEnum.SealType>]} sealTypes 盖章类型
 * @property {[Module: Schema.Types.Mixed]} uploadPos 初始放置文档地址
 * @property {String} uploadPos.storagePath 存储到smb的真实路径
 * @property {String} uploadPos.fileName 存储前的真实文件名
 * @property {[Module: Schema.Types.Mixed]} finalPos 最终存档位置
 * @property {String} finalPos.storagePath 存档的真实路径
 * @property {String} finalPos.fileName 存档前的真实文件名
 * @property {String} archiveDir 最终存档的文件夹
 * @property {String} signatory 签约方
 * @property {String} proposer 提出者
 * @property {String} tag 文档所属标签
 */
const DocumentSchema = new Schema({
  name: { type: String, required: true },
  uid: { type: Schema.ObjectId, required: true },
  deptId: { type: Schema.ObjectId, required: true },
  category: { type: Number, required: true },
  type: { type: Number, required: true },
  createTime: { type: Date, required: true, default: Date.now },
  updateTime: { type: Date },
  startTime: { type: Date, required: true },
  endTime: { type: Date, required: true },
  format: { type: Boolean, default: false },
  decisiveNo: { type: String },
  decisiveLink: { type: String },
  contractMoney: { type: Number, default: 0 },
  applyMoney: { type: Number, default: 0 },
  currencyUnit: { type: Number, default: FEnum.CurrencyUnit.rmb },
  copies: { type: Number, required: true },
  pages: { type: Number, required: true },
  description: { type: String },
  state: { type: Number, required: true },
  sealTypes: { type: [Number] },
  pagingSeal: { type: Boolean, default: false },
  uploadPos: { type: [Schema.Types.Mixed], required: true },
  finalPos: { type: [Schema.Types.Mixed] },
  archiveDir: { type: String },
  signatory: { type: String },
  proposer: { type: String },
  tagId: { type: Schema.ObjectId }
});

DocumentSchema.index({ uid: 1 });
DocumentSchema.index({ name: 1 }, { unique: true });
DocumentSchema.index({ deptId: 1 });
DocumentSchema.index(
  { signatory: 1 },
  { partialFilterExpression: { signatory: { $exists: true } } }
);
DocumentSchema.index(
  { tagId: 1 },
  { partialFilterExpression: { tagId: { $exists: true } } }
);

DocumentSchema.plugin(BaseModel);

mongoose.model("Document", DocumentSchema);
