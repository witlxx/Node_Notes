"use strict";

const mongoose = require("mongoose");
const BaseModel = require("./extends");
const Schema = mongoose.Schema;
const { FEnum } = require("../util");

/**
 * @class DocumentLogSchema
 * @memberOf module:FModel
 * @constructor
 * @mixes Document
 * @property {Date} createTime 发起流程时间
 * @property {Boolean} status 流程是否启动(denied或reject，流程status为false;启用状态status为true)
 * @property {ObjectId} docId 被审核(操作)的文档id
 * @property {Boolean} emergency 是否紧急
 * @property {ObjectId} reqUid 发起审核(操作)者
 * @property {ObjectId} reqDeptId 发起者直属部门
 * @property {ObjectId} resUid 给予审核(操作)者
 * @property {ObjectId} resDeptId 给予者直属部门
 * @property {<Module: FEnum.ResOptType>} resOptType 给予操作者需要给予的操作动作类型
 * @property {Date} deadline 希望纳期
 * @property {<Module: FEnum.OptState>} resOptState 路径中的处理者处理文档的状态
 * @property {Boolean} resOptTime 受理者操作文档时间
 * @property {Date} startTime 出借开始时间
 * @property {Date} endTime 出借截止时间
 */
const DocumentLogSchema = new Schema({
  docId: { type: Schema.ObjectId, required: true },
  docName: { type: String },
  reqUid: { type: Schema.ObjectId, required: true },
  reqName: { type: String },
  reqDeptId: { type: Schema.ObjectId },
  reqDeptName: { type: String },
  emergency: { type: Boolean, default: false },
  deadline: { type: Date },
  status: { type: Boolean, default: true },
  createTime: { type: Date, required: true, default: Date.now },
  resUid: { type: Schema.ObjectId, required: true },
  resName: { type: String },
  resDeptId: { type: Schema.ObjectId },
  resOptType: { type: Number, required: true },
  resOptState: {
    type: Number,
    required: true,
    default: FEnum.OptState.pending
  },
  resOptTime: { type: Date },
  startTime: { type: Date },
  endTime: { type: Date }
});

DocumentLogSchema.index({ resUid: 1 });
DocumentLogSchema.plugin(BaseModel);
mongoose.model("DocumentLog", DocumentLogSchema);
