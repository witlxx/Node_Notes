"use strict";
const bcrypt = require("bcrypt");
const mongoose = require("mongoose");
const BaseModel = require("./extends");
const FEnum = require("../util/FEnum");
const Schema = mongoose.Schema;

/**
 * @class UserSchema
 * @memberOf module:FModel
 * @constructor
 * @mixes Document
 * @property {ObjectId} _id uid 用户唯一标识符
 * @property {String} name 用户名,可以为中文
 * @property {String} password 密码 默认值为111111
 * @property {String} email 用户唯一邮箱
 * @property {String} avatar 用户头像
 * @property {String} account 唯一用户名
 * @property {Boolean} isAdmin 是否为管理员
 * @property {ObjectId} deptId 用户直属部门id
 * @property {Boolean} isLeader 用户是否为直属部门的最高领导
 * @property {[<Module: FEnum.UserRole>]} roles 用户角色
 * @property {[<Module: FEnum.UserAccess>]} permissions 用户权限
 * @property {ObjectId} agentUid 代理人uid
 * @property {<module:FEnum.UserStatus>} status 用户状态
 * @property {Date} createTime 创建时间
 */
const UserSchema = new Schema({
  name: { type: String, required: true },
  avatar: { type: String },
  email: { type: String, required: true },
  account: { type: String, required: true },
  password: { type: String, default: bcrypt.hashSync("111111", 5) },
  isAdmin: { type: Boolean, required: true, default: false },
  deptId: { type: Schema.ObjectId, required: true },
  isLeader: { type: Boolean, required: true, default: false },
  roles: { type: [Number], required: true },
  permissions: { type: [Number], reqired: true },
  agentUid: { type: Schema.ObjectId, default: null },
  status: { type: Number, default: FEnum.UserStatus.enable },
  createTime: { type: Date, required: true, default: Date.now }
});

UserSchema.index({ email: 1 }, { unique: true });
UserSchema.index({ account: 1 }, { unique: true });
UserSchema.index({ email: 1, account: 1 });
UserSchema.index({ deptId: 1 });
UserSchema.plugin(BaseModel);

mongoose.model("User", UserSchema);
