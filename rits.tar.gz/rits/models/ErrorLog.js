"use strict";

const mongoose = require("mongoose");
const BaseModel = require("./extends");
const Schema = mongoose.Schema;

/**
 * @class ErrorLogSchema
 * @memberOf module:FModel
 * @constructor
 * @mixes Document
 * @property {Number} statusCode
 * @property {String} url
 * @property {String} query
 * @property {String} requestBody
 * @property {String} method
 * @property {String} requestIP
 * @property {String} responseError
 * @property {Date} createTime 错误生成时间
 */
const ErrorLogSchema = new Schema({
  statusCode: { type: Number, required: true },
  url: { type: String, required: true },
  query: { type: String },
  requestBody: { type: String },
  method: { type: String, required: true },
  requestIP: { type: String },
  responseIP: { type: String },
  responseError: {type: String},
  createTime: { type: Date, default: Date.now }
});

ErrorLogSchema.plugin(BaseModel);

mongoose.model("ErrorLog", ErrorLogSchema);
