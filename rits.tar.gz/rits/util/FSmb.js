"use strict";
const SMB2 = require("smb2");
const Joi = require("@hapi/joi");
const Promise = require("bluebird");
const fs = require("fs");
const FUtil = require("./FUtil");
const FError = require("./FError");
const config = require(process.env.config);
const { key: smbkey, iv: smbiv } = config.aeskey.smb;

module.exports = smbBody => {
  const schema = Joi.object().keys({
    share: Joi.string().required(),
    domain: Joi.string().required(),
    username: Joi.string().required(),
    password: Joi.string().required()
  });
  const validate = FUtil.reqVerify(smbBody, schema);
  if (!validate) return errorHandler(FError.InvalidParameters());

  const smbService = new SMB2(smbBody);

  function errorHandler(error) {
    switch (error && (error.code || error.message)) {
      case "STATUS_LOGON_FAILURE":
        return FError.InvalidLogin("invalid loginname or password");
      case "ECONNREFUSED":
        return FError.ConnectRefused("invlid url to connect");
      case "File does not exists":
        return FError.DocumentNotFound("document no found");
      default:
        return error || FError.RequestError("internal error");
    }
  }

  this.exists = folderPath => {
    return new Promise((resolve, reject) => {
      smbService.exists(`${folderPath}`, (err, exist) => {
        if (err) return resolve(errorHandler(err));
        resolve({ link: true, exist });
      });
    });
  };

  this.uploadFile = file => {
    return new Promise((resolve, reject) => {
      let buffers = [];
      const { path, name } = file;
      const stream = fs.createReadStream(path);
      stream.on("error", err => {
        return resolve(errorHandler(err));
      });
      stream.on("data", data => buffers.push(data));
      stream.on("end", () => {
        const buff = Buffer.concat(buffers);
        const buffEnc = FUtil.encryptBuffer(buff, smbkey, smbiv);
        smbService.writeFile(
          name,
          Buffer.from(buffEnc, "hex"),
          {
            encoding: "utf-8"
          },
          err => {
            if (err) return resolve(errorHandler(err));
            resolve(true);
          }
        );
      });
    });
  };

  this.downloadFile = filename => {
    return new Promise((resolve, reject) => {
      smbService.readFile(filename, {}, (err, data) => {
        if (err) return resolve(errorHandler(err));
        const deHex = FUtil.decryptBuffer(data, smbkey, smbiv);
        const buffer = Buffer.from(deHex, "hex");
        resolve({ filename, buffer });
      });
    });
  };

  this.unlink = path => {
    return new Promise((resolve, reject) => {
      if (!path) return resolve(errorHandler(FError.InvalidParameters()));
      smbService.unlink(path, err => {
        if (err) return resolve(errorHandler(err));
        resolve(true);
      });
    });
  };

  this.readdir = path => {
    return new Promise((resolve, reject) => {
      smbService.readdir(path || "", (err, data) => {
        if (err) return resolve(errorHandler(err));
        resolve(data);
      });
    });
  };

  this.createFolder = dirName => {
    return new Promise((resolve, reject) => {
      if (!dirName) return resolve(errorHandler(FError.InvalidParameters()));
      smbService.mkdir(dirName, (err, data) => {
        if (err) return resolve(errorHandler(err));
        resolve(data);
      });
    });
  };

  return this;
};
