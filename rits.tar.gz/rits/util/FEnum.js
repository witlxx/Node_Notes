"use strict";

/**
 * 用户角色
 * enum for UserRole
 * @readonly
 * @enum {Number}
 */
exports.UserRole = {
  normal: 0 /**普通用户 */,
  auditor: 1 /**文书审查担当 */,
  sealer: 2 /**盖章担当 */,
  taxer: 3 /**免税处理担当 */,
  archiver: 4 /**存档处理担当 */,
  bscSealer: 5 /**bsc部门合同担当 */
};

/**
 * 用户权限
 * enum for UserAccess
 * @readonly
 * @enum {Number}
 */
exports.UserAccess = {
  view: 1 /**查看|预览 */,
  update: 2 /**创建|编辑 */,
  audit: 3 /**审查 */,
  seal: 4 /**盖章 */,
  tax: 5 /**免税处理 */,
  archive: 6 /**存档 */,
  delete: 7 /**删除 */
};

/**
 * 文档类别
 * enum for DocumentCategory
 * @readonly
 * @enum {Number}
 */
exports.DocumentCategory = {
  incomeContract: 1 /**收入合同 */,
  exportContract: 2 /**支出合同 */,
  specialContract: 3 /**特殊合同(不涉金额) */,
  normalContract: 4 /**一般合同(不涉金额) */,
  instrument: 5 /**文书 */,
  otherInstrument: 6 /**其他文书 */
};

/**
 * 文件夹路径名称
 * enum for StorageDirType
 * @readonly
 * @enum {String}
 */
exports.StorageDirType = {
  avatars: "avatars",
  documents: {
    incomeContract: "incomeContracts",
    exportContract: "exportContracts",
    specialContract: "specialContracts",
    normalContract: "normalContracts",
    instrument: "instruments",
    otherInstrument: "otherInstruments"
  }
};

/**
 * 文档类型
 * enum for DocumentType
 * @readonly
 * @enum {Number}
 */
exports.DocumentType = {
  domesticTrustee: 10 /**境内受托开发合同 */,
  foreginTrustee: 11 /**境外受托开发合同*/,
  sale: 12 /**产品销售合同*/,
  inMaintenance: 13 /**收入维保合同*/,
  inOthers: 14 /**其他收入合同*/,
  purchase: 21 /**商品购买合同*/,
  consignee: 22 /**委托加工合同*/,
  dispatch: 23 /**人员派遣合同*/,
  lease: 24 /**租赁合同*/,
  exMaintenance: 25 /**支出维保合同*/,
  exOthers: 26 /**其他支出合同*/,
  intention: 31 /**战略合作意向合同*/,
  cooperation: 32 /**业务合作基本合同*/,
  confidentiality: 33 /**保密合同*/,
  labor: 34 /**劳动合同*/,
  spOthers: 35 /**其他特别合同*/,
  formatConfidentiality: 41 /**格式保密合同*/,
  renewLabor: 42 /**劳动合同(续签)*/,
  patentAgency: 43 /**专利申请代理合同*/,
  assigning: 44 /**定期采用人员第三方协议*/,
  intern: 45 /**实习生协议*/,
  noOthers: 46 /**其他一般合同*/,
  personnel: 51 /**人事相关证明*/,
  withdrawal: 52 /**退工单*/,
  introduction: 53 /**公司介绍信*/,
  patentApply: 54 /**专利申请资料*/,
  clearance: 55 /**进出口通关资料*/,
  invoice: 56 /**销售发票*/,
  loan: 57 /**支票贷记凭证*/,
  exchange: 58 /**银行外汇申请支付*/,
  wrOthers: 59 /**其他文档*/,
  trademarkReg: 61 /**特许，商标注册证 */,
  confirmation: 62 /**合作意向确认书 */,
  customsDuties: 63 /**进出口海关税赋 */,
  insurancePolicy: 64 /**保险单 */
};

/**
 * 货币单位
 * enum for CurrencyUnit
 * @readonly
 * @enum {Number}
 */
exports.CurrencyUnit = {
  rmb: 1 /**人民币 */,
  yen: 2 /**日元 */,
  dollar: 3 /**美元 */
};

/**
 * 盖章类型
 * enum for SealType
 * @readonly
 * @enum {Number}
 */
exports.SealType = {
  official: 1 /**	公司公章	*/,
  contract: 2 /**	公司合同章	*/,
  financial: 3 /**	公司财务专用章	*/,
  legal: 4 /**	公司法定代表人章	*/,
  finRep: 5 /**	公司财务负责人章	*/,
  signatureSeal: 6 /**	公司总经理签字章	*/,
  invoice: 7 /**	公司发票专用章	*/,
  borrow: 8 /**公司借机器借用证明（公章） */
};

/**
 * 文档状态
 * enum for DocumentState
 * @readonly
 * @enum {Number}
 */
exports.DocumentState = {
  making: 1 /**做成中*/,
  auditing: 2 /**审查中*/,
  accepting: 3 /**盖章受理中*/,
  sealing: 4 /**盖章中*/,
  sealed: 5 /**盖章完成*/,
  tax: 6 /**免税处理中*/,
  archiving: 7 /**存档中*/,
  archived: 8 /**存档完成*/,
  denied: 9 /**否决*/,
  reject: 10 /**保留(打回重新修改再提交)*/,
  lent: 11 /**已借出*/
};

/**
 * 文档状态中文
 * enum for DocumentStateCN
 * @readonly
 * @enum {String}
 */
exports.DocumentStateCN = {
  denied: "否决",
  sealed: "盖章完成",
  archived: "存档完成",
  reject: "建议保留"
};

/**
 * 请求操作类型
 * enum for ReqOptType
 * @readonly
 * @enum {Number}
 */
exports.ReqOptType = {
  create: 1 /**创建 */,
  edit: 2 /**编辑文档 */,
  save: 3 /**保存文档 */,
  keep: 4 /**申请直接存档 */,
  seal: 5 /**申请盖章 */,
  tax: 6 /**申请免税处理 */,
  archive: 7 /**申请存档 */
};

/**
 * 响应操作类型
 * enum for ResOptType
 * @readonly
 * @enum {Number}
 */
exports.ResOptType = {
  audit: 1 /**去审查 */,
  accept: 2 /**去做盖章前审查 */,
  seal: 3 /**去盖章 */,
  tax: 4 /**去做免税处理 */,
  archive: 5 /**去存档 */,
  lend: 6 /**去出借 */,
  back: 7 /**去归还 */,
  reject: 8 /**保留(修改后再提交) */,
  deny: 9 /**否决 */
};

/**
 * 响应操作的中文翻译
 * enum for ResOptCN
 * @readonly
 * @enum {String}
 */
exports.ResOptCN = {
  audit: "去审查",
  accept: "去做盖章前审查",
  seal: "去盖章",
  tax: "去做免税处理",
  archive: "去存档",
  lend: "去出借",
  return: "去归还",
  reject: "保留",
  deny: "否决"
};

/**
 * 用户状态
 * enum for UserStatus
 * @readonly
 * @enum {Number}
 */
exports.UserStatus = {
  enable: 1 /**正常使用 */,
  disable: 0 /**已删除 */
};

/**
 * 存储入es的内容类型
 * enum for ESType
 * @readonly
 * @enum {String}
 */
exports.ESType = {
  doc: "_doc",
  dept: "_dept",
  user: "_user"
};

/**
 * 项目中需要用到的缓存key
 * enum for RedisKey
 * @readonly
 * @enum {String}
 */
exports.RedisKey = {
  /**密码找回 */
  passBack: "doc:email:{email}:account:{account}",
  storageSmb: "doc:storage:smb"
};

/**
 * 系统设定类型
 * enum for SetType
 * @readonly
 * @enum {Number}
 */
exports.SetType = {
  email: 1 /**系统设定中的邮件设定 */,
  storage: 2 /**系统设定中的存储设定 */
};

/**
 * 存储类型
 * enum for StorageType
 * @readonly
 * @enum {Number}
 */
exports.StorageType = {
  smb: 1 /**系统设定中存储设定的子类型(存储在smb中) */
};

/**
 * 重置密码方式
 * enum for PassUpdMethod
 * @readonly
 * @enum {Number}
 */
exports.PassUpdMethod = {
  reset: 1 /**通过旧密码找回密码*/,
  email: 2 /**通过邮箱找回密码 */
};

/**
 * 我的文档请求类型
 * enum for MyDocOpt
 * @readonly
 * @enum {Number}
 */
exports.MyDocOpt = {
  dealt: 1 /**待我处理 */,
  making: 2 /**我做成中的 */,
  created: 3 /**我创建的 */
};

/**
 * 文档的处理状态
 * enum for OptState
 * @readonly
 * @enum {Number}
 */
exports.OptState = {
  pending: 1 /**还没轮到此人处理 */,
  dealing: 2 /**轮到此人了但此人还未处理 */,
  finished: 3 /**此人处理完了 */
};

/**
 * 邮件通知内容类型
 * enum for MailContentType
 * @readonly
 * @enum {Number}
 */
exports.MailContentType = {
  optNeed: 1 /**请求操作型邮件 */,
  notification: 2 /**纯通知型邮件 */
};

/**
 * 查看记录类型
 * enum for RecordType
 * @readonly
 * @enum {Number}
 */
exports.RecordType = {
  review: 1 /**审核记录 */,
  lend: 2 /**出借记录 */
};
