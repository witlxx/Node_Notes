const nodemailer = require("nodemailer");

function getSecure(secure) {
  switch (secure) {
    case "tls":
      return true;
    case "starttls":
    case "none":
      return false;
  }
}

/**
 *
 * @function sendMail
 *
 * @param {String} arg[0].host smtp server address
 * @param {Number} arg[0].port stmp server port
 * @param {"tls","starttls","none"} arg[0].secure secure type (tls,starttls,none) default:none
 * @param {Object} [auth] auth
 * @param {String} auth.user username
 * @param {String} auth.pass password
 * @param {String} to send to email exp:"test@test.com,test2.test.com"
 * @param {String} subject
 * @param {Object} arg[5] send text or html
 *
 * @return {Object} info nodemailer Reply
 *
 */

exports.sendMail = async (
  { host, port, secure },
  auth,
  from,
  to,
  subject,
  { text, html }
) => {
  const { user, pass } = auth || {};
  if (!user || !pass) auth = null;
  const transporter = nodemailer.createTransport({
    host: host,
    port: port,
    secure: getSecure(secure) /* true for 465, false for other ports */,
    auth
  });
  const info = await transporter.sendMail({
    from /* sender address*/,
    to /* list of receivers*/,
    subject /* Subject line*/,
    text /* plain text body*/,
    html /* html body*/
  });
  return info;
};

/**
 *
 * @function verify
 *
 * @param {String} arg[0].host smtp server address
 * @param {Number} arg[0].port stmp server port
 * @param {"tls","starttls","none"} arg[0].secure secure type (tls,starttls,none) default:none
 * @param {Object} [auth] auth
 * @param {String} auth.user username
 * @param {String} auth.pass password
 *
 * @return {Object} nodemailer verify result
 *
 */
exports.verify = async ({ host, port, secure }, auth) => {
  const { user, pass } = auth || {};
  if (!user || !pass) auth = null;
  const transporter = nodemailer.createTransport({
    host: host,
    port: port,
    secure: getSecure(secure) /* true for 465, false for other ports*/,
    auth
  });
  return await transporter.verify();
};
