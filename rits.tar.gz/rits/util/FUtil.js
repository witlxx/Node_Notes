"use strict";
const crypto = require("crypto");
const os = require("os");
const FEnum = require("./FEnum");
const _ = require("lodash");
const moment = require("moment");
const parse = require("csv-parse");
const fs = require("fs");
const { Document: Doc } = require("../connect").models;
moment.locale("zh-cn");

/**
 * 加密buffer
 */
exports.encryptBuffer = (buff, key, iv) => {
  let cipher = crypto.createCipheriv("aes-128-cbc", key, iv);
  return cipher.update(buff, "", "hex") + cipher.final("hex");
};

/**
 * 解密buffer
 */
exports.decryptBuffer = (buff, key, iv) => {
  let decipher = crypto.createDecipheriv("aes-128-cbc", key, iv);
  return decipher.update(buff, "", "hex") + decipher.final("hex");
};

/**
 * 格式化时间
 * @function formatDate
 * @return {Data}
 */
exports.formatDate = function(date, friendly) {
  date = moment(date);
  if (friendly) {
    return date.fromNow();
  } else {
    return date.format("YYYY-MM-DD HH:mm");
  }
};

/**
 * 检验请求参数是否是后端要求的参数
 * @function reqVerify
 * @param {Object} body 前端请求参数
 * @param {Function} schema 后端要求参数<netSchema中定义>
 * @return {Boolean}
 */
exports.reqVerify = (body, schema) => {
  if (!body || !schema) return false;
  const validateResult = schema.validate(body, { allowUnknown: true });
  if (validateResult.error) {
    return false;
  } else {
    return validateResult.value || {};
  }
};

/**
 * 获取请求服务机器的ip
 * @function getRemoteIP
 * @param {Object} req
 * @return {String}
 */
exports.getRemoteIP = req => {
  return (
    req.headers["x-forwarded-for"] ||
    (req.connection && req.connection.remoteAddress) ||
    (req.socket && req.socket.remoteAddress) ||
    (req.connection &&
      req.connection.socket &&
      req.connection.socket.remoteAddress) ||
    ""
  );
};

/**
 * 获取本地服务器ip
 * @function getLocalIP
 * @return {String} localIP
 */
exports.getLocalIP = () => {
  const interfaces = os.networkInterfaces();
  let localIP = "";
  Object.keys(interfaces).forEach(function(name) {
    interfaces[name].forEach(function(f) {
      if ("IPv4" !== f.family || f.internal !== false) {
        return;
      }
      localIP += f.address + ";";
    });
  });
  return localIP;
};

/**
 * 检查是否是ObjectId
 * @function checkObjectId
 * @param {String} value
 * @return {Boolean}
 */
exports.checkObjectId = value => {
  const checkForHexRegExp = new RegExp("^[0-9a-fA-F]{24}$");
  return value && value.length === 24 && checkForHexRegExp.test(value);
};

/**
 * json hash map
 */
exports.hashMap = (docs, key) => {
  if (!key || !Array.isArray(docs) || docs.length === 0) return {};
  let temp,
    result = {};
  (docs || []).forEach(doc => {
    temp = doc[`${key}`];
    result[temp] = doc;
  });
  return result;
};

exports.matchSelfAccess = (isAdmin, roles) => {
  if (!Array.isArray(roles) || roles.length === 0) return [];
  if (!isAdmin && roles.length === 1 && roles[0] === FEnum.UserRole.normal)
    return FEnum.UserAccess.view;
  const accesses = [FEnum.UserAccess.view, FEnum.UserAccess.update];
  for (let i = 0; i < roles.length; i++) {
    if (roles[i] === FEnum.UserRole.auditor) {
      accesses.push(FEnum.UserAccess.audit);
    }
    if (
      roles[i] === FEnum.UserRole.sealer ||
      roles[i] === FEnum.UserRole.bscSealer
    ) {
      accesses.push(FEnum.UserAccess.seal);
    }
    if (roles[i] === FEnum.UserRole.taxer) {
      accesses.push(FEnum.UserAccess.tax);
    }
    if (roles[i] === FEnum.UserRole.archiver) {
      accesses.push(FEnum.UserAccess.archive);
    }
  }
  if (isAdmin) {
    accesses.push(FEnum.UserAccess.delete);
  }
  return _.uniq(_.sortBy(accesses));
};

exports.parseCSV = csvfile => {
  return new Promise((resolve, reject) => {
    if (!csvfile) return resolve(false);
    const stream = fs.readFileSync(csvfile).toString();
    const output = [];
    parse(stream, {
      trim: true,
      skip_empty_lines: true
    })
      .on("readable", function() {
        let record;
        /**此处赋值不是判断 */
        while ((record = this.read())) {
          output.push(record);
        }
      })
      .on("end", function() {
        resolve(output);
      });
  });
};

exports.mongoToObject = body => {
  if (!body) return {};
  return body.toObject ? body.toObject() : body;
};

/**
 * 请求操作状态流转图
 * @function reqOptLimit
 * @param {ObjectId} docId
 * @param {<Module: FEnum.ReqOptType>} reqOptType
 * @return {Boolean}
 */
exports.reqOptLimit = async (docId, reqOptType) => {
  let limit = true;
  const { keep, seal, tax, archive } = FEnum.ReqOptType;
  const { making, reject, sealed } = FEnum.DocumentState;
  const { auditing, archiving } = FEnum.DocumentState;

  const doc = await Doc.findById(docId);
  if (!doc || !doc.state) return false;

  switch (reqOptType) {
    case keep:
    case seal:
      limit = doc.state === making || doc.state === reject;
      if (limit)
        await Doc.updateOne({ _id: docId }, { $set: { state: auditing } });
      break;
    case tax:
      limit = doc.state === sealed;
      if (limit) await Doc.updateOne({ _id: docId }, { $set: { state: tax } });
      break;
    case archive:
      limit = doc.state === sealed;
      if (limit)
        await Doc.updateOne({ _id: docId }, { $set: { state: archiving } });
      break;
    default:
      limit = false;
      break;
  }
  return limit;
};

/**
 * 响应操作状态流转图
 * @function resOptLimit
 * @param {ObjectId} docId
 * @param {<Module: FEnum.ResOptType>} resOptType
 * @return {Boolean}
 */
exports.resOptLimit = async (docId, resOptType) => {
  let limit = true;
  const { audit, accept, seal } = FEnum.ResOptType;
  const { tax, archive, lend, reject, back, deny } = FEnum.ResOptType;
  const { lent, sealing } = FEnum.DocumentState;
  const { archiving, auditing, accepting, archived } = FEnum.DocumentState;

  const doc = await Doc.findById(docId);
  if (!doc || !doc.state) return false;

  switch (resOptType) {
    case audit:
    case reject:
    case deny:
      limit = doc.state === auditing;
      break;
    case accept:
      limit = doc.state === accepting || doc.state === auditing;
      break;
    case seal:
      limit = doc.state === accepting || doc.state === sealing;
      break;
    case tax:
      limit = doc.state === tax;
      break;
    case archive:
      limit = doc.state === archiving;
      break;
    case lend:
      limit = doc.state === archived;
      break;
    case back:
      limit = doc.state === lent;
      break;
    default:
      limit = false;
      break;
  }
  return limit;
};
