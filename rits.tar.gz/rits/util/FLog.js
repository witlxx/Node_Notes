"use strict";
const winston = require("winston");
const FUtil = require("./FUtil");
const { models: FModels } = require("../connect");

exports.generateErrorLog = async (statusCode, error, ctx) => {
  if (!error) {
    return true;
  }
  const [url, query] = (ctx.originalUrl || "").split("?");
  return {
    statusCode,
    url,
    query,
    requestBody: JSON.stringify(ctx.response.body || ""),
    method: ctx.request.method,
    requestIP: FUtil.getRemoteIP(ctx.request),
    responseIP: FUtil.getLocalIP(),
    responseError: "" + error,
    createTime: new Date()
  };
};

exports.saveLog = async errlog => {
  const { ErrorLog } = FModels;
  const errorLog = new ErrorLog(errlog);
  return await errorLog.save();
};

const logger = winston.createLogger({
  level: "info",
  format: winston.format.json(),
  defaultMeta: { service: "doc-service" },
  transports: [new winston.transports.Console()]
});

/** 后续拓展 */
exports.loggerError = async error => {
  const { errorMsg } = error;
  logger.level = "debug";
  return await logger.log("error", errorMsg);
};
