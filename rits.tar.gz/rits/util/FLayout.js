"use strict";
const FLog = require("./FLog");
const FError = require("./FError");

/**
 * @function layout
 * @param {module: FError} err 错误类型对象或null
 * @param {Object} ctx
 * @param {Object} body 返回参数或null
 */
exports.layout = async (err, ctx, body) => {
  const error = err;
  /**系统异常 */
  if (err && !err.statusCode) {
    switch (err.code || err.message) {
      case 11000:
        err = FError.DuplicateKey("mongo duplicate key error");
        err.statusCode = 403;
        break;
      case "jwt expired":
        err = FError.TokenExpired("token has expired");
        err.statusCode = 401;
        break;
      default:
        err = FError.RequestError();
        err.statusCode = 500;
        break;
    }
  }
  /**定义的错误类型和协议码 */
  const method = ctx.method;
  let status = 200;
  switch (method) {
    case "GET":
    case "get":
      status = 200;
      break;
    case "POST":
    case "post":
      status = 201;
      break;
    case "PUT":
    case "put":
    case "DELETE":
    case "delete":
      status = 204;
      break;
    default:
      status = 200;
      break;
  }
  if (body) status = 200;
  const { errorCode, errorMsg, statusCode } = err
    ? err
    : { errorCode: 0, errorMsg: null, statusCode: status };
  /**生成日志 */
  if (error) {
    FLog.loggerError({ errorMsg: error });
    if (process.env.NODE_ENV === "production") {
      const log = await FLog.generateErrorLog(statusCode, error, ctx);
      await FLog.saveLog(log);
    }
  }
  /**返回参数 */
  ctx.status = statusCode;
  ctx.body = {
    errorCode,
    errorMsg,
    data: body
  };
};
