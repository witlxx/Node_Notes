"use strict";

class FError extends Error {
  constructor(errorCode, errorMsg) {
    super(errorMsg);
    this.errorCode = errorCode;
    this.errorMsg = errorMsg;
  }

  static ErrorMap(error) {
    return {
      [FError.RequestError]: 1000,
      [FError.InvalidParameters]: 2001,
      [FError.InvalidAdmin]: 2002,
      [FError.NotFoundDept]: 2003,
      [FError.DeptDelNotAllowed]: 2004,
      [FError.NotFoundUser]: 2005,
      [FError.UserHasExist]: 2006,
      [FError.VerifyFailure]: 2007,
      [FError.DuplicateKey]: 2008,
      [FError.NotFoundRule]: 2009,
      [FError.VerifyPathFailure]: 2010,
      [FError.AuthenticationRole]: 2011,
      [FError.EmailHasUsed]: 2012,
      [FError.InvalidLogin]: 2013,
      [FError.ConnectRefused]: 2014,
      [FError.DocumentNotFound]: 2015,
      [FError.SystemSetNotFinished]: 2016,
      [FError.TokenExpired]: 2017,
      [FError.InvalidFormatData]: 2018,
      [FError.DocAuditNotAllowed]: 2019,
      [FError.DocAcceptNotAllowed]: 2020,
      [FError.DocSealNotAllowed]: 2021,
      [FError.DocArchiveNotAllowed]: 2022,
      [FError.DocNotOptAccess]: 2023
    }[error];
  }

  /**
   * 以下定义为错误枚举类型
   * @function isTypeOf
   * @para  {*} error
   * @param {*} ErrorType
   */
  static isTypeOf(error, ErrorType) {
    if (!error) return false;
    return error.errorCode === FError.ErrorMap(ErrorType);
  }

  /**
   * 系统错误
   */
  static RequestError(errorMsg) {
    return new FError(1000, errorMsg || "internal error");
  }

  /**
   * 非法参数
   */
  static InvalidParameters(errorMsg) {
    return new FError(2001, errorMsg || "invalid parameters");
  }

  /**
   * 没有管理员权限
   */
  static InvalidAdmin(errorMsg) {
    return new FError(2002, errorMsg);
  }

  /**
   * 未查找到部门
   */
  static NotFoundDept(errorMsg) {
    return new FError(2003, errorMsg);
  }

  /**
   * 该部门可能为其他部门的父部门，不允许被删除
   */
  static DeptDelNotAllowed(errorMsg) {
    return new FError(2004, errorMsg);
  }

  /**
   * 未查找到用户
   */
  static NotFoundUser(errorMsg) {
    return new FError(2005, errorMsg);
  }

  /**
   * 用户已存在
   */
  static UserHasExist(errorMsg) {
    return new FError(2006, errorMsg);
  }

  /**
   * 验证失败
   */
  static VerifyFailure(errorMsg) {
    return new FError(2007, errorMsg);
  }

  /**
   * 重复索引报错
   */
  static DuplicateKey(errorMsg) {
    return new FError(2008, errorMsg);
  }

  /**
   * 未查找到规则
   */
  static NotFoundRule(errorMsg) {
    return new FError(2009, errorMsg);
  }

  /**
   * 验证审批路径失败
   */
  static VerifyPathFailure(errorMsg) {
    return new FError(2010, errorMsg);
  }

  /**
   * 角色和权限不匹配
   */
  static AuthenticationRole(errorMsg) {
    return new FError(2011, errorMsg);
  }

  /**
   * 邮箱已经被占用
   */
  static EmailHasUsed(errorMsg) {
    return new FError(2012, errorMsg);
  }

  /**
   * 账号或密码错误
   */
  static InvalidLogin(errorMsg) {
    return new FError(2013, errorMsg);
  }

  /**
   * 错误的连接地址,连接被拒绝
   */
  static ConnectRefused(errorMsg) {
    return new FError(2014, errorMsg);
  }

  /**
   * 文档不存在
   */
  static DocumentNotFound(errorMsg) {
    return new FError(2015, errorMsg);
  }

  /**
   * 系统设定需要重新设置
   */
  static SystemSetNotFinished(errorMsg) {
    return new FError(2016, errorMsg);
  }

  /**
   * token过期
   */
  static TokenExpired(errorMsg) {
    return new FError(2017, errorMsg);
  }

  /**
   * 数据格式不正确
   */
  static InvalidFormatData(errorMsg) {
    return new FError(2018, errorMsg);
  }

  /**
   * 不允许提交审查
   */
  static DocAuditNotAllowed(errorMsg) {
    return new FError(2019, errorMsg);
  }

  /**
   * 不允许提交盖章审批
   */
  static DocAcceptNotAllowed(errorMsg) {
    return new FError(2020, errorMsg);
  }
  /**
   * 不允许提交盖章
   */
  static DocSealNotAllowed(errorMsg) {
    return new FError(2021, errorMsg);
  }

  /**
   * 不允许提交存档
   */
  static DocArchiveNotAllowed(errorMsg) {
    return new FError(2022, errorMsg);
  }

  /**
   * 没有对文档的操作权限
   */
  static DocNotOptAccess(errorMsg) {
    return new FError(2023, errorMsg);
  }
}

module.exports = FError;
