"use strict";
const Joi = require("@hapi/joi");
const { FEnum } = require("../util");

exports.postRule = Joi.object().keys({
  name: Joi.string().required(),
  categories: Joi.array()
    .items(Joi.number().valid(Object.values(FEnum.DocumentCategory)))
    .required(),
  auditPath: Joi.array().items(
    Joi.object({
      /**<module: FEnum.UserRole> 课长、部长职位角色均为 -1*/
      role: Joi.number()
        .valid(FEnum.UserRole.auditor, -1)
        .default(-1),
      /**<module: FModels.Department.level> */
      level: Joi.any(),
      roleName: Joi.string().required()
    })
  ),
  sealPath: Joi.array().items(
    Joi.object({
      /**<module: FEnum.UserRole> 课长、部长职位角色均为 -1*/
      role: Joi.number()
        .valid(FEnum.UserRole.sealer, -1)
        .default(-1),
      /**<module: FModels.Department.level> */
      level: Joi.any(),
      roleName: Joi.string().required()
    })
  )
});

exports.matchProcess = Joi.object().keys({
  reqOptType: Joi.number()
    .valid([
      FEnum.ReqOptType.keep /**请求审查完直接存档 */,
      FEnum.ReqOptType.seal /**请求审查=>盖章前审核=>盖章 */,
      FEnum.ReqOptType.archive /**请求盖完章的文档直接进行存档 */,
      FEnum.ReqOptType.tax /**请求盖章完成的文档去做免税处理然后存档 */
    ])
    .required(),
  documentCategory: Joi.number()
    .valid(Object.values(FEnum.DocumentCategory))
    .required(),
  multiple: Joi.boolean().default(false)
});

exports.igniteProcess = Joi.object().keys({
  docId: Joi.string().required(),
  docName: Joi.string().required(),
  reqUid: Joi.string().required(),
  reqName: Joi.string().required(),
  reqDeptId: Joi.string().required(),
  reqDeptName: Joi.string().required(),
  emergency: Joi.boolean().default(false),
  deadline: Joi.date(),
  paths: Joi.array().items(
    Joi.object({
      resUid: Joi.string().required(),
      resName: Joi.string().required(),
      resDeptId: Joi.string().required(),
      resOptType: Joi.number()
        .valid([
          FEnum.ResOptType.audit,
          FEnum.ResOptType.accept,
          FEnum.ResOptType.seal,
          FEnum.ResOptType.archive,
          FEnum.ResOptType.tax
        ])
        .required()
    })
  )
});
