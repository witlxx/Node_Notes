"use strict";
const Joi = require("@hapi/joi");

exports.postDept = Joi.object().keys({
  name: Joi.string().required(),
  referred: Joi.string().required(),
  parentId: Joi.string(),
  description: Joi.string(),
  isSealDept: Joi.boolean()
});
