"use strict";
const Joi = require("@hapi/joi");

exports.smbScheam = Joi.object().keys({
  share: Joi.string().required(),
  domain: Joi.string().default("WORKGROUP"),
  username: Joi.string().required(),
  password: Joi.string().required()
});

exports.stmpSchema = Joi.object().keys({
  host: Joi.string().required(),
  port: Joi.any().required(),
  secure: Joi.string().default("tls"),
  user: Joi.string(),
  pass: Joi.string(),
  sender: Joi.string().required()
});
