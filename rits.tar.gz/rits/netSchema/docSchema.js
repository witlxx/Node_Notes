"use strict";
const Joi = require("@hapi/joi");
const { FEnum } = require("../util");

exports.getDocs = Joi.object().keys({
  startTime: Joi.string(),
  endTime: Joi.string(),
  state: Joi.number(),
  tagId: Joi.string(),
  deptId: Joi.string(),
  category: Joi.number(),
  type: Joi.number(),
  signatory: Joi.string(),
  currencyUnit: Joi.number(),
  dealine: Joi.number(),
  page: Joi.number(),
  count: Joi.number(),
  keyword: Joi.string()
});

exports.postDoc = Joi.object().keys({
  uid: Joi.string().required(),
  name: Joi.string().required(),
  startTime: Joi.string(),
  endTime: Joi.string(),
  category: Joi.number().required(),
  type: Joi.number().required(),
  format: Joi.boolean(),
  decisiveNo: Joi.string(),
  decisiveLink: Joi.string(),
  currencyUnit: Joi.number(),
  contractMoney: Joi.number(),
  applyMoney: Joi.number(),
  copies: Joi.number().required(),
  pages: Joi.number().required(),
  proposer: Joi.string(),
  description: Joi.string(),
  state: Joi.number()
    .valid([FEnum.DocumentState.making, FEnum.DocumentState.reject])
    .default(FEnum.DocumentState.making)
    .required(),
  uploadPos: Joi.array().items(
    Joi.object({
      storagePath: Joi.string().required(),
      fileName: Joi.string().required()
    })
  ),
  sealTypes: Joi.array().items(Joi.number())
});

exports.uploadDoc = Joi.object().keys({
  storage: Joi.number()
    .valid(Object.values(FEnum.StorageType))
    .default(FEnum.StorageType.smb),
  documentCategory: Joi.number()
    .valid(Object.values(FEnum.DocumentCategory))
    .required()
});

exports.archiveDoc = Joi.object().keys({
  finalPos: Joi.array().items(
    Joi.object({
      storagePath: Joi.string().required(),
      fileName: Joi.string().required()
    })
  ),
  archiveDir: Joi.string().required()
});

exports.lentRequest = Joi.object().keys({
  lentUid: Joi.string().required(),
  startTime: Joi.date(),
  endTime: Joi.date()
});
