"use strict";
const Joi = require("@hapi/joi");
const { FEnum } = require("../util");

exports.postUser = Joi.object().keys({
  name: Joi.string().required(),
  email: Joi.string().required(),
  account: Joi.string().required(),
  deptId: Joi.string().required(),
  isAdmin: Joi.boolean(),
  isLeader: Joi.boolean(),
  roles: Joi.array()
    .items(Joi.number().valid(Object.values(FEnum.UserRole)))
    .required(),
  permissions: Joi.array()
    .items(Joi.number().valid(Object.values(FEnum.UserAccess)))
    .required()
});

exports.postMailer = Joi.object().keys({
  account: Joi.string().required(),
  email: Joi.string().required()
});

exports.modifyPass = Joi.object().keys({
  account: Joi.string().required(),
  email: Joi.string().required(),
  type: Joi.number().required(),
  newPass: Joi.string().required(),
  repeatPass: Joi.string().required(),
  originPass: Joi.string(),
  verification: Joi.string()
});

exports.putOneUser = Joi.object().keys({
  email: Joi.string().required(),
  agentUid: Joi.string(),
  account: Joi.string().required()
});
