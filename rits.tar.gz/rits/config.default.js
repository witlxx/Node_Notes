module.exports = {
  mongo: "mongodb://172.20.1.3:27017/hood_dev",
  domain: "",
  redis: {
    port: 6379,
    host: "172.20.1.2",
    db: 0,
    password: ""
  },
  rootDept: {
    level: 1 /**企业的level */
  },
  es: {
    host: "172.20.1.5:9200"
  },
  docESIndex: "rits_doc_search_index",
  aeskey: {
    secret: "41b76a42-be3b-4805-abdc-2f63e8442ced",
    smb: {
      key: "1234567891234576",
      iv: "1234567891234576"
    }
  }
};
