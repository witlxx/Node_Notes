"use strict";
const proxy = require("../proxy");
const _ = require("lodash");
const userPorxy = proxy.userProxy;
const docProxy = proxy.docProxy;
const FError = require("../util/FError");
const { FUtil, FLayout, FEnum } = require("../util");
const config = require(process.env.config);
const { postUser, postMailer } = require("../netSchema/userSchema");
const { modifyPass, putOneUser } = require("../netSchema/userSchema");

async function authenticationRole(isAdmin, roles, accesses) {
  const permissions = FUtil.matchSelfAccess(isAdmin, roles);
  return _.uniq(_.sortBy(accesses)).toString() === permissions.toString();
}

exports.userLogin = async (ctx, next) => {
  const req = ctx.request;
  const { account, password } = req.body;
  if (!account || !password) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const user = await userPorxy.validateLogin(req.body);
  if (!user) {
    ctx.throw(403, FError.NotFoundUser("no user found"));
  }
  if (!user.account) {
    ctx.throw(403, FError.VerifyFailure("wrong password"));
  }
  await FLayout.layout(null, ctx, user);
  await next();
};

exports.postUser = async (ctx, next) => {
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, postUser);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const { isAdmin, roles, permissions } = req.body;
  const auth = await authenticationRole(isAdmin, roles, permissions);
  if (!auth) {
    ctx.throw(400, FError.AuthenticationRole("role and permission not match"));
  }
  const user = await userPorxy.createUser(req.body);
  if (!user) {
    ctx.throw(403, FError.UserHasExist("user has existed"));
  }
  if (!user.name) {
    ctx.throw(404, FError.NotFoundDept("dept not found"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.putUser = async (ctx, next) => {
  const suid = ctx.params["suid"];
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, postUser);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const { isAdmin, roles, permissions } = req.body;
  const auth = await authenticationRole(isAdmin, roles, permissions);
  if (!auth) {
    ctx.throw(400, FError.AuthenticationRole("role and permission not match"));
  }
  const user = await userPorxy.updateUser(suid, req.body);
  if (!user) {
    ctx.throw(403, FError.EmailHasUsed("email has been used"));
  }
  if (!user.name) {
    ctx.throw(404, FError.NotFoundUser("user or dept not found"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.deleteUser = async (ctx, next) => {
  const suid = ctx.params["suid"];
  const user = await userPorxy.disableUser(suid);
  if (!user) {
    ctx.throw(403, FError.NotFoundUser("no user found"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.countUsers = async (ctx, next) => {
  const req = ctx.request;
  const count = await userPorxy.countUsers(req.query);
  await FLayout.layout(null, ctx, { count: count });
  await next();
};

exports.getUsers = async (ctx, next) => {
  const req = ctx.request;
  const users = await userPorxy.searchUsers(req.query);
  await FLayout.layout(null, ctx, users);
  await next();
};

exports.agents = async (ctx, next) => {
  const req = ctx.request;
  const uid = req.user._id;
  const agents = await userPorxy.getColleagues(uid, config.rootDept.level + 2);
  await FLayout.layout(null, ctx, agents);
  await next();
};

exports.postMailer = async (ctx, next) => {
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, postMailer);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const pass = await userPorxy.mailValidate(req.body);
  if (!pass) {
    ctx.throw(403, FError.NotFoundUser("no user found"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.modifyPass = async (ctx, next) => {
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, modifyPass);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const { newPass, repeatPass } = req.body;
  if (newPass !== repeatPass) {
    ctx.throw(400, FError.InvalidParameters("two inconsistent passwords"));
  }
  const pass = await userPorxy.updatePass(req.body);
  if (!pass) {
    ctx.throw(403, FError.VerifyFailure("wrong password or verification"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.getOneUser = async (ctx, next) => {
  const req = ctx.request;
  const uid = req.user._id;
  let user = await userPorxy.findById(uid);
  if (!user) {
    ctx.throw(404, FError.NotFoundUser("user not found"));
  }
  if (user.toObject) user = user.toObject();
  if (user.agentUid) {
    const agent = await userPorxy.findById(user.agentUid);
    user.agentName = agent ? agent.name : null;
  }
  if (user.avatar) {
    const avatarBuffer = await docProxy.acquireFile(user.avatar);
    if (!avatarBuffer) {
      ctx.throw(404, FError.SystemSetNotFinished("system reset needed"));
    }
    user.avatarBuffer = avatarBuffer.buffer.toString("base64");
  }
  await FLayout.layout(null, ctx, user);
  await next();
};

exports.putOneUser = async (ctx, next) => {
  const req = ctx.request;
  const uid = req.user._id;
  const validate = FUtil.reqVerify(ctx.request.body, putOneUser);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const result = await userPorxy.updateUserData(uid, validate);
  if (!result) {
    ctx.throw(404, FError.SystemSetNotFinished("system reset needed"));
  }
  if (!result.name) {
    ctx.throw(403, FError.EmailHasUsed("no user found or email has been used"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.postAvatar = async (ctx, next) => {
  let avatar, avatarBuffer;
  const req = ctx.request;
  const uid = req.user._id;
  const file = req.files.file;
  const storage = +req.body.storage || FEnum.StorageType.smb;
  if (file && file.path && +storage === FEnum.StorageType.smb) {
    const { path, name } = file;
    const dir = FEnum.StorageDirType.avatars;
    avatar = await docProxy.storeFile({ uid, storage, dir, path, name });
    await userPorxy.searchUserByIdAndUpdate(uid, { avatar });
    avatarBuffer = await docProxy.acquireFile(avatar);
  }
  await FLayout.layout(null, ctx, {
    avatar,
    avatarBuffer: avatarBuffer.buffer.toString("base64")
  });
  await next();
};

exports.csvUser = async (ctx, next) => {
  const file = ctx.request.files.file;
  if (!file) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const { path } = file;
  const dataList = await FUtil.parseCSV(path);
  const result = await userPorxy.csvLoadUsers(dataList);
  if (result && result.errorLine) {
    ctx.throw(
      403,
      FError.InvalidFormatData(`invalid format in line ${result.errorLine}`)
    );
  }
  await FLayout.layout(null, ctx, result);
  await next();
};

exports.getUsersInDept = async (ctx, next) => {
  const deptId = ctx.params["deptId"];
  const users = await userPorxy.findUsers({ deptId });
  await FLayout.layout(null, ctx, users);
  await next();
};
