"use strict";
const FError = require("../util/FError");
const { FUtil, FLayout, FEnum } = require("../util");
const { ruleProxy, processProxy, docProxy } = require("../proxy");
const { postRule } = require("../netSchema/ruleSchema");
const { matchProcess, igniteProcess } = require("../netSchema/ruleSchema");
const { archiveDoc, lentRequest } = require("../netSchema/docSchema");

exports.getRules = async (ctx, next) => {
  const req = ctx.request;
  const rules = await ruleProxy.searchRules(req.query);
  await FLayout.layout(null, ctx, rules);
  await next();
};

exports.countRules = async (ctx, next) => {
  const req = ctx.request;
  const count = await ruleProxy.countRules(req.query);
  await FLayout.layout(null, ctx, { count });
  await next();
};

exports.deleteRule = async (ctx, next) => {
  const ruleHashId = ctx.params["ruleHashId"];
  const rule = await ruleProxy.deleteRule(ruleHashId);
  if (!rule) {
    ctx.throw(404, FError.NotFoundRule("not found rule"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.postRule = async (ctx, next) => {
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, postRule);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  await ruleProxy.createRule(req.body);
  await FLayout.layout(null, ctx);
  await next();
};

exports.putRule = async (ctx, next) => {
  const req = ctx.request;
  const ruleHashId = ctx.params["ruleHashId"];
  const validate = FUtil.reqVerify(req.body, postRule);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  await ruleProxy.updateRules(ruleHashId, req.body);
  await FLayout.layout(null, ctx);
  await next();
};

exports.matchProcess = async (ctx, next) => {
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, matchProcess);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const path = await processProxy.acquirePaths(validate, req.user);
  if (!path) {
    ctx.throw(404, FError.NotFoundRule("fail to match valid rule"));
  }
  await FLayout.layout(null, ctx, path);
  await next();
};

exports.igniteProcess = async (ctx, next) => {
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, igniteProcess);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const lit = await processProxy.litProcess(validate);
  if (!lit) {
    ctx.throw(403, FError.DocAuditNotAllowed("doc operation not allowed"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.resOptProcess = async (ctx, next) => {
  let validate;
  const { lend, back, archive } = FEnum.ResOptType;
  const docId = ctx.params["docId"];
  const type = +ctx.params["type"];
  const req = ctx.request;
  const user = req.user;
  const uid = user._id;
  if (type === archive) {
    validate = FUtil.reqVerify(req.body, archiveDoc);
    if (!validate) {
      ctx.throw(400, FError.InvalidParameters("invalid parameters"));
    }
  }
  if ([lend, back].includes(type)) {
    const { lentBody } = req.body;
    validate = lentBody ? FUtil.reqVerify(lentBody, lentRequest) : false;
    if (!validate) {
      ctx.throw(400, FError.InvalidParameters("invalid parameters"));
    }
  }
  const doc = await docProxy.searchDocById(docId);
  if (!doc) {
    ctx.throw(404, FError.DocumentNotFound("doc not found"));
  }
  const result = await processProxy.lanuchOptProcess(uid, doc, type, req.body);
  if (!result) {
    ctx.throw(403, FError.DocNotOptAccess("no access to act document"));
  }
  await FLayout.layout(null, ctx);
  await next();
};
