"use strict";
const FError = require("../util/FError");
const { FUtil, FLayout, FEnum } = require("../util");
const { docProxy, tagProxy, deptProxy } = require("../proxy");
const { getDocs, postDoc, uploadDoc } = require("../netSchema/docSchema");
const config = require(process.env.config);

exports.getDocs = async (ctx, next) => {
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, getDocs);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const docs = await docProxy.searchDocs(validate);
  await FLayout.layout(null, ctx, docs);
  await next();
};

exports.countDocs = async (ctx, next) => {
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, getDocs);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const results = await docProxy.countDocs(validate);
  await FLayout.layout(null, ctx, results);
  await next();
};

exports.uploadDoc = async (ctx, next) => {
  const req = ctx.request;
  const { path, name } = req.files.file || {};
  const validate = FUtil.reqVerify(req.body, uploadDoc);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const { storage, documentCategory } = validate;
  const key = Object.keys(FEnum.DocumentCategory).filter(
    category => FEnum.DocumentCategory[`${category}`] === documentCategory
  );
  let storagePath = "";
  if (key.length > 0) {
    const dir = FEnum.StorageDirType.documents[`${key[0]}`];
    storagePath = await docProxy.storeFile({
      uid: req.user._id,
      storage,
      dir,
      path,
      name
    });
  }
  await FLayout.layout(null, ctx, {
    storagePath,
    fileName: name
  });
  await next();
};

exports.downloadDoc = async (ctx, next) => {
  const req = ctx.request;
  const { storagePath } = req.body || {};
  if (!storagePath) {
    ctx.throw(400, FError.InvalidParameters("invalid parameter path"));
  }
  const fileBuffer = await docProxy.acquireFile(storagePath);
  ctx.attachment(fileBuffer.filename);
  ctx.body = fileBuffer.buffer;
  await next();
};

exports.createDoc = async (ctx, next) => {
  const req = ctx.request;
  const validate = await FUtil.reqVerify(req.body, postDoc);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const doc = await docProxy.createDoc(validate);
  await FLayout.layout(null, ctx, doc);
  await next();
};

exports.updateDoc = async (ctx, next) => {
  const req = ctx.request;
  const docId = ctx.params["docId"];
  const validate = await FUtil.reqVerify(req.body, postDoc);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const doc = await docProxy.updateDoc(docId, validate);
  await FLayout.layout(null, ctx, doc);
  await next();
};

exports.deleteDoc = async (ctx, next) => {
  const docId = ctx.params["docId"];
  const doc = await docProxy.deleteDoc(docId);
  await FLayout.layout(null, ctx, doc);
  await next();
};

exports.getTags = async (ctx, next) => {
  const tags = await tagProxy.findTags();
  await FLayout.layout(null, ctx, tags);
  await next();
};

exports.getSignatory = async (ctx, next) => {
  const signatories = await docProxy.aggreagteSignatory();
  await FLayout.layout(null, ctx, signatories);
  await next();
};

exports.queryDept = async (ctx, next) => {
  const level = +ctx.request.query.level || config.rootDept.level + 2;
  const depts = await deptProxy.findDepts({ level });
  await FLayout.layout(null, ctx, depts);
  await next();
};

exports.getMyDocs = async (ctx, next) => {
  let documents = [];
  const type = +ctx.params["type"] || FEnum.MyDocOpt.dealt;
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, getDocs);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  switch (type) {
    case FEnum.MyDocOpt.dealt:
      documents = await docProxy.acquireDealtDocs(req.user._id, validate);
      break;
    case FEnum.MyDocOpt.making:
      documents = await docProxy.acquireMakingDocs(req.user._id, validate);
      break;
    case FEnum.MyDocOpt.created:
      documents = await docProxy.acquireCreatedDocs(req.user._id, validate);
      break;
    default:
      break;
  }
  await FLayout.layout(null, ctx, documents);
  await next();
};

exports.countMyDocs = async (ctx, next) => {
  let results = {};
  const type = +ctx.params["type"] || FEnum.MyDocOpt.dealt;
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, getDocs);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  switch (type) {
    case FEnum.MyDocOpt.dealt:
      results = await docProxy.countDealtDocs(req.user._id, validate);
      break;
    case FEnum.MyDocOpt.making:
      results = await docProxy.countMakingDocs(req.user._id, validate);
      break;
    case FEnum.MyDocOpt.created:
      results = await docProxy.countCreatedDocs(req.user._id, validate);
      break;
    default:
      results = { totalCount: 0, totalAmount: 0, details: [] };
      break;
  }
  await FLayout.layout(null, ctx, results);
  await next();
};

exports.fectchRecords = async (ctx, next) => {
  const docId = ctx.params["docId"];
  const type = +ctx.params["type"];
  const results = await docProxy.getOptRecords(docId, type);
  await FLayout.layout(null, ctx, results);
  await next();
};
