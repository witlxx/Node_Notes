"use strict"

exports.userController = require("./userController");
exports.deptController = require("./deptController");
exports.docController = require("./docController");
exports.ruleController = require("./ruleController");
exports.systemController = require("./systemController");