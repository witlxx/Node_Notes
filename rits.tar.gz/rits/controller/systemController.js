"use strict";
const { systemProxy } = require("../proxy");
const { FLayout, FEnum, FUtil } = require("../util");
const FError = require("../util/FError");
const { smbScheam, stmpSchema } = require("../netSchema/systemSetSchema");

exports.getSystemSet = async (ctx, next) => {
  const sets = await systemProxy.findSystemSets();
  await FLayout.layout(null, ctx, sets);
  await next();
};

exports.postSystemSet = async (ctx, next) => {
  let validate;
  const req = ctx.request;
  const { setType, type, content } = req.body;
  if (
    !Object.values(FEnum.SetType).includes(setType) ||
    (setType === FEnum.SetType.storage &&
      !Object.values(FEnum.StorageType).includes(type))
  ) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  
  if (setType === FEnum.SetType.email) {
    validate = await FUtil.reqVerify(content, stmpSchema);
  }
  if (setType === FEnum.SetType.storage) {
    validate = await FUtil.reqVerify(content, smbScheam);
  }
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  if(!req.body.domain){
    req.body.content = validate;
  }
  const set = await systemProxy.setSystemSet(req.body);
  if (!set) {
    ctx.throw(403, FError.VerifyFailure("verification expired"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.vertify = async (ctx, next) => {   //连接验证的接口   同上
  let validate;
  const req = ctx.request;
  const { setType, type, content } = req.body;
  if (
    !Object.values(FEnum.SetType).includes(setType) ||
    (setType === FEnum.SetType.storage &&
      !Object.values(FEnum.StorageType).includes(type))
  ) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  if (setType === FEnum.SetType.email) {
    validate = await FUtil.reqVerify(content, stmpSchema);
  }
  if (setType === FEnum.SetType.storage) {
    validate = await FUtil.reqVerify(content, smbScheam);
  }
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  if(!req.body.domain){
    req.body.content = validate;
  }
  const set = await systemProxy.vertify(req.body);
  if (!set) {
    ctx.throw(403, FError.VerifyFailure("verification expired"));
  }
  await FLayout.layout(null, ctx);
  await next();
};