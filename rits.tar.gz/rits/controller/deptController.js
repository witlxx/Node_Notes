"use strict";

const FError = require("../util/FError");
const { FUtil, FLayout } = require("../util");
const { deptProxy } = require("../proxy");
const { postDept } = require("../netSchema/deptScheam");

exports.postDept = async (ctx, next) => {
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, postDept);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const dept = await deptProxy.createDept(req.body);
  if (!dept) {
    ctx.throw(404, FError.NotFoundDept("not found parent dept"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.putDept = async (ctx, next) => {
  const deptId = ctx.params["deptId"];
  const req = ctx.request;
  const validate = FUtil.reqVerify(req.body, postDept);
  if (!validate) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const dept = await deptProxy.updateDept(deptId, req.body);
  if (!dept) {
    ctx.throw(404, FError.NotFoundDept("not found parent dept"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.countDepts = async (ctx, next) => {
  const req = ctx.request;
  const count = await deptProxy.countDepts(req.query);
  await FLayout.layout(null, ctx, { count: count });
  await next();
};

exports.getDepts = async (ctx, next) => {
  const req = ctx.request;
  const depts = await deptProxy.searchDepts(req.query);
  await FLayout.layout(null, ctx, depts);
  await next();
};

exports.treeDepts = async (ctx, next) => {
  const req = ctx.request;
  const depts = await deptProxy.findChildDepts(req.query);
  await FLayout.layout(null, ctx, depts);
  await next();
};

exports.deleteDept = async (ctx, next) => {
  const deptId = ctx.params["deptId"];
  const depts = await deptProxy.deleteDept(deptId);
  if (!depts) {
    ctx.throw(403, FError.DeptDelNotAllowed("dept not allowed to delete"));
  }
  await FLayout.layout(null, ctx);
  await next();
};

exports.csvDept = async (ctx, next) => {
  const file = ctx.request.files.file;
  if (!file) {
    ctx.throw(400, FError.InvalidParameters("invalid parameters"));
  }
  const { path } = file;
  const dataList = await FUtil.parseCSV(path);
  const result = await deptProxy.csvLoadDepts(dataList);
  if (result && result.errorLine) {
    ctx.throw(
      403,
      FError.InvalidFormatData(`invalid format in line ${result.errorLine}`)
    );
  }
  await FLayout.layout(null, ctx, result);
  await next();
};
