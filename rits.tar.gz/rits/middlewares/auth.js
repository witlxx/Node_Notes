"use strict";
const FModels = require("../connect/models");
const FError = require("../util/FError");
const { Document: Doc } = FModels;

/**
 * 确定是否是管理员
 */
exports.admin = async (ctx, next) => {
  const user = ctx.request.user;
  if (!user.isAdmin) {
    ctx.throw(403, FError.InvalidAdmin("invalid admin parameters"));
  }
  await next();
};

/**
 * 确定文档操作者和文档创建者是否是同一个人
 */
exports.sameUser = async (ctx, next) => {
  const req = ctx.request;
  const { user, query, body } = req;
  const docId = query.docId || body.docId || ctx.params["docId"];
  if (!docId) {
    ctx.throw(400, FError.InvalidParameters(`invalid parameter docId`));
  }
  const doc = await Doc.findById(docId);
  if (!doc) {
    ctx.throw(404, FError.DocumentNotFound(`documents not found`));
  }
  if (user && user._id.toString() !== doc.uid.toString()) {
    ctx.throw(403, FError.AuthenticationRole(`req operator not doc creator`));
  }
  await next();
};
