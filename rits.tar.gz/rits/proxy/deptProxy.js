"use strict";

const FModels = require("../connect").models;
const Dept = FModels.Department;
const User = FModels.User;
const config = require(process.env.config);
const FEnum = require("../util/FEnum");
const FUtil = require("../util/FUtil");
const { postDept } = require("../netSchema/deptScheam");

/**
 * 确定该部门的level及是否是管理印章的部门(包括bsc中心的子部门)
 * @function setDeptLevel
 * @param {Object} deptBody
 * @param {ObjectId} deptBody.parentId
 * @returns {*}
 */
async function setDeptLevel(deptBody) {
  const { parentId } = deptBody || {};
  if (!parentId) {
    deptBody.level = config.rootDept.level;
  } else {
    /**查找并更新该父部门的叶子状态 */
    const patr = await Dept.findByIdAndUpdate(parentId, {
      $set: { isLeaf: false }
    });
    if (!patr) return false;
    deptBody.level = patr.level + 1;
    if (patr.level !== config.rootDept.level) {
      const center = await exports.getPatrDept(
        parentId,
        config.rootDept.level + 1
      );
      deptBody.isSealDept = !!center.isSealDept;
    }
  }
  return deptBody;
}

/**
 * @function createDept
 * {<netSchema.deptSchema.postDept>}
 * @param {String} name
 * @param {String} referred
 * @param {ObjectId} parentId
 * @param {String} description
 * @returns {*}
 */
exports.createDept = async deptBody => {
  deptBody = await setDeptLevel(deptBody);
  return deptBody ? await new Dept(deptBody).save() : deptBody;
};

/**
 * @function updateDept
 * {<netSchema.deptSchema.postDept>}
 * @param {ObjectId} deptId
 * @param {String} name
 * @param {String} referred
 * @param {ObjectId} parentId
 * @param {String} description
 * @returns {*}
 */
exports.updateDept = async (deptId, deptBody) => {
  deptBody = await setDeptLevel(deptBody);
  return deptBody
    ? await Dept.findByIdAndUpdate(deptId, { $set: deptBody })
    : deptBody;
};

/**
 * 查找部门的条件整理
 * @function queryCondition
 * @param {Object} deptQuery
 * @param {String} deptBody.keyword 关键字
 * @param {ObjectId} deptBody.parentId 父部门id
 * @param {Boolean} deptBody.isLeaf 是否为叶子节点
 * @returns {Object}
 */
async function queryCondition(deptQuery) {
  const { keyword, parentId, isLeaf } = deptQuery;
  let condition = keyword
    ? {
        $or: [
          { name: new RegExp(keyword, "i") },
          { referred: new RegExp(keyword, "i") }
        ]
      }
    : {};
  if (parentId) {
    condition.parentId = parentId;
  }
  if (isLeaf) {
    condition.isLeaf = true;
  }
  return condition;
}

/**
 * 利用关键字keyword进行模糊搜索(name, referred)
 * @function countDepts
 * @param {<deptQuery>}
 * @param {String} keyword 关键字
 * @param {ObjectId} parentId 父部门
 * @param {Boolean} isLeaf 是否只查询叶子部门
 * @returns {*}
 */
exports.countDepts = async deptQuery => {
  const condition = await queryCondition(deptQuery);
  return await Dept.countDocuments(condition);
};

/**
 * 补充dept的父部门名称和其领导的信息
 * @function complementDept
 * @param {Array} depts
 * @param {<Module: FModels.Department>} deptIds[0]
 * @returns {*}
 */
async function complementDept(depts) {
  if (depts.length === 0) return [];
  let leadQuery = [],
    parentQuery = [],
    leaderMap = {},
    patrDeptMap = {};
  const deptIds = depts.map(dept => dept._id);
  const parentIds = depts.map(dept => dept.parentId);
  /**查找部门领导 */
  if (deptIds.length !== 0) {
    deptIds.forEach(deptId => {
      leadQuery.push({
        deptId: deptId
      });
    });
    const leaders = await User.find({
      $or: leadQuery,
      isLeader: true,
      status: FEnum.UserStatus.enable
    });
    leaderMap = FUtil.hashMap(leaders, "deptId");
  }
  /**查找父部门信息 */
  if (parentIds.length !== 0) {
    parentIds.forEach(parentId => {
      parentQuery.push({
        _id: parentId
      });
    });
    const patrDepts = await Dept.find({ $or: parentQuery });
    patrDeptMap = FUtil.hashMap(patrDepts, "_id");
  }
  return depts.map(dept => {
    if (dept.toObject) dept = dept.toObject();
    let leader = leaderMap[`${dept._id}`] && leaderMap[`${dept._id}`].name;
    let parentName =
      patrDeptMap[`${dept.parentId}`] && patrDeptMap[`${dept.parentId}`].name;
    dept.leader = leader || "";
    dept.parentName = parentName || "";
    return dept;
  });
}

/**
 * 利用关键字keyword进行模糊搜索(name, referred)
 * @function searchDepts
 * @param {<deptQuery>}
 * @param {Number} page 第几页
 * @param {Number} count 一页的条数
 * @param {String} keyword 关键字
 * @param {ObjectId} parentId 父部门
 * @param {Boolean} isLeaf 是否只查询叶子部门
 * @returns {*}
 */
exports.searchDepts = async deptQuery => {
  const limit = +deptQuery.count || 20;
  const skip = (+deptQuery.page || 0) * limit;
  const condition = await queryCondition(deptQuery);
  const depts = await Dept.find(condition)
    .skip(skip)
    .limit(limit)
    .sort({ createTime: -1 });
  return await complementDept(depts);
};

/**
 * 根据父parentId返回子部门deptId
 * @function findDepts
 * @param {<deptQuery>}
 * @param {String} parentId
 * @param {Boolean} isLeaf(false || null => 查询非叶子节点)
 * @returns {*}
 */
exports.findChildDepts = async deptQuery => {
  const { parentId, isLeaf } = deptQuery;
  let condition = {};
  if (parentId) {
    condition.parentId = parentId;
    if (isLeaf === "false" || isLeaf === false) {
      condition.isLeaf = false;
    }
  } else {
    condition.level = config.rootDept.level;
  }
  return await Dept.find(condition);
};

/**
 * 删除某叶子部门
 * @function deleteDept
 * @param {ObjectId} deptId
 * @returns {*}
 */
exports.deleteDept = async deptId => {
  deptId = deptId.trim();
  const user = await User.findOne({ deptId, status: FEnum.UserStatus.enable });
  if (user) return false;
  const dept = await Dept.findOneAndDelete({ _id: deptId, isLeaf: true });
  const patr = await Dept.findOne({ parentId: dept.parentId });
  if (!patr) {
    await Dept.update({ _id: dept.parentId }, { $set: { isLeaf: true } });
  }
  return !!dept;
};

/**
 * 查找deptId在level层级的父部门id
 * @function getPatrDept
 * @param {ObjectId} deptId
 * @param {Number} level
 * @return {<Module: FModels.Document>}
 */
exports.getPatrDept = async (deptId, level) => {
  if (!level) return false;
  if (Number.isNaN(+level)) return false;
  if (level < 0) return false;
  const dept = await Dept.findById(deptId);
  if (!dept) return false;
  if (dept.level <= level) return dept;
  return await exports.getPatrDept(dept.parentId, level);
};

/**
 * @function treeKinDeptIds
 * @param {ObjectId} deptId
 * @return {void}
 */
let kinDeptIds = [];
async function treeKinDeptIds(deptId) {
  const dept = await Dept.findById(deptId);
  kinDeptIds.push(dept._id);
  const subDepts = await exports.findChildDepts({ parentId: deptId });
  const subDeptIds = subDepts.map(subDept => subDept._id);
  for (let i = 0; i < subDeptIds.length; i++) {
    await treeKinDeptIds(subDeptIds[i]);
  }
}

/**
 * 获取该父部门下的所有子孙部门
 * @function getKinDeptIds
 * @param {ObjectId} deptId
 * @returns {Array}
 */
exports.getKinDeptIds = async deptId => {
  await treeKinDeptIds(deptId);
  const kinList = kinDeptIds;
  kinDeptIds = [];
  return kinList;
};

/**
 * 将csv的数据导入表中
 * @function csvLoadDepts
 * @param {Array} deptLists
 * @return {*}
 */
exports.csvLoadDepts = async deptLists => {
  const schemas = [];
  let deptSchema = {},
    line = 0;
  if (deptLists.length === 0) return false;
  const keys = deptLists[0];
  for (let j = 1; j < deptLists.length; j++) {
    let dept = deptLists[j];
    for (let i = 0; i < keys.length; i++) {
      deptSchema[`${keys[i]}`] = dept[i];
      schemas.push(deptSchema);
    }
    if (!FUtil.reqVerify(schemas[j], postDept)) {
      line = j;
      break;
    }
  }
  if (line === 0) {
    await Dept.insertMany(schemas);
    return { count: deptLists.length - 1 };
  } else {
    return { errorLine: line };
  }
};

/**
 * 根据条件查询部门
 * @function findDepts
 * @param {Object} condition
 * @returns {*}
 */
exports.findDepts = async condition => {
  condition = condition || {};
  return await Dept.find(condition);
};
