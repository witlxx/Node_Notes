"use strict";

const { models: FModels, redis: RedisClient } = require("../connect");
const { FEnum, FSmb, FMail } = require("../util");
const SystemSet = FModels.SystemSet;
const ExpireTime = 5 * 60 * 1000;

exports.getSmbSet = async () => {
  const key = FEnum.RedisKey.storageSmb;
  let smbConfigure = await RedisClient.hgetall(key);
  if (!smbConfigure || !smbConfigure.share) {
    const storage = await SystemSet.findOne({
      setType: FEnum.SetType.storage,
      type: FEnum.StorageType.smb
    });
    if (storage) {
      smbConfigure = storage.content;
      await RedisClient.hmset(key, smbConfigure, ExpireTime);
    } else {
      return false;
    }
  }
  return smbConfigure;
};

exports.findSystemSets = async () => {
  return await SystemSet.find({});
};

async function validateMail(mailBody) {
  const { host, port, secure, user, pass } = mailBody;
  return await FMail.verify({ host, port, secure }, { user, pass });
}

async function validateSmb(smbBody) {
  return !((await FSmb(smbBody).readdir()) instanceof Error);
}

exports.setSystemSet = async setBody => {
  let validation;
  const { setType, type, content } = setBody;
  if (setType === FEnum.SetType.email) {
    validation = await validateMail(content);
  }
  if (setType === FEnum.SetType.storage) {
    if (type === FEnum.StorageType.smb) {
      validation = await validateSmb(content);
    }
  }
  if (!!validation) {
    await SystemSet.deleteOne({ setType });
    return await new SystemSet(setBody).save();
  }
};

exports.vertify = async setBody => {
  let validation;
  const { setType, type, content } = setBody;
  if (setType === FEnum.SetType.email) {
    validation = await validateMail(content);
  }
  if (setType === FEnum.SetType.storage) {
    if (type === FEnum.StorageType.smb) {
      validation = await validateSmb(content);
    }
  }
  return !!validation;
};