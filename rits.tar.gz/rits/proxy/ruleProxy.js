"use strict";
const FModels = require("../connect").models;
const Rule = FModels.Rule;
const UUIDV4 = require("uuid/v4");

async function queryCondition(ruleQuery) {
  const { keyword } = ruleQuery || {};
  let condition = keyword
    ? {
        $or: [{ name: new RegExp(keyword, "i") }]
      }
    : {};
  return condition;
}

exports.searchRules = async ruleQuery => {
  ruleQuery = ruleQuery || {};
  const condition = await queryCondition(ruleQuery);
  return await Rule.aggregate([
    { $match: condition },
    {
      $group: {
        _id: "$ruleHashId",
        categories: { $push: "$category" },
        name: { $first: "$name" },
        auditPath: { $first: "$auditPath" },
        sealPath: { $first: "$sealPath" }
      }
    }
  ]);
};

exports.countRules = async ruleQuery => {
  const condition = await queryCondition(ruleQuery);
  const aggre = await Rule.aggregate([
    { $match: condition },
    { $group: { _id: "$ruleHashId" } }
  ]);
  return aggre.length;
};

exports.deleteRule = async ruleHashId => {
  ruleHashId = ruleHashId.trim();
  const rule = await Rule.deleteMany({ ruleHashId });
  return !!rule;
};

function formatRuleSchema(ruleBody) {
  const { name, categories, auditPath, sealPath } = ruleBody;
  const ruleHashId = UUIDV4();
  if (categories.length === 0) return [];
  const rules = [];
  categories.forEach(category => {
    rules.push({
      name,
      category,
      auditPath,
      sealPath,
      ruleHashId
    });
  });
  return rules;
}

exports.createRule = async ruleBody => {
  const rules = formatRuleSchema(ruleBody);
  return await Rule.insertMany(rules);
};

/**
 * 批量规则类型不允许编辑
 * @function updateRules
 * @param {ObjectId} ruleHashId
 * @param {Object} ruleBody
 * @param {[Object]} ruleBody.auditPath
 * @param {[Object]} ruleBody.sealPath
 * @param {Number} ruleBody.auditPath.role
 * @param {Number} ruleBody.auditPath.level
 * @param {String} ruleBody.auditPath.roleName
 * @returns {*}
 */
exports.updateRules = async (ruleHashId, ruleBody) => {
  await Rule.deleteMany({ ruleHashId });
  return await exports.createRule(ruleBody);
};
