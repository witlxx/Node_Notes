"use strict";
const { models: FModels } = require("../connect");
const { Tag } = FModels;

exports.findTags = async _ => {
  return await Tag.find();
};

