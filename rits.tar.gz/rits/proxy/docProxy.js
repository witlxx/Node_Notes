"use strict";
const ObjectId = require("mongoose").Types.ObjectId;
const esClient = require("../connect").elastic;
const { models: FModels } = require("../connect");
const { Document: Doc, Department: Dept, User, DocumentLog: DocLog } = FModels;
const config = require(process.env.config);
const { FEnum, FSmb, FUtil } = require("../util");
const ESType = FEnum.ESType;
const systemProxy = require("./systemProxy");
const deptProxy = require("./deptProxy");
const FError = require("../util/FError");

/**
 * 格式化传入es的数据
 * @function _buildESDoc
 * @param {String} index [config.docESIndex]
 * @param {String} doc
 * @param {Boolean} refresh
 * @returns {*}
 */
function _buildESDoc(index, doc, refresh) {
  if (!doc || !doc.name || !doc._id) {
    return null;
  }
  const body = { name: doc.name, id: doc._id + "" };
  return {
    id: "" + doc._id,
    refresh: refresh || false,
    index: index,
    type: ESType.doc,
    body: body
  };
}

/**
 * 新建es doc
 * @function indexESDoc
 * @param index
 * @param doc
 * @param refresh
 * @returns {*}
 */
exports.indexESDoc = async (index, doc, refresh) => {
  const value = _buildESDoc(index, doc, refresh);
  if (!value) return false;
  return esClient.index(value);
};

/**
 * 删除es
 * @function deleteESDoc
 * @param {String} index
 * @param {ObjectId} docId
 * @param {Boolean} refresh
 * @return {*}
 */
exports.deleteESDoc = async (index, docId, refresh) => {
  return esClient.delete({
    index: index,
    id: "" + docId,
    type: ESType.doc,
    refresh: refresh || false
  });
};

/**
 * 关键字查找
 * @function searchESDocs
 * @param {String} index
 * @param {String} keyword
 * @param {Number} page
 * @param {Number} count
 * @returns {*}
 */
exports.searchESDocs = async (index, keyword, page, count) => {
  const reqBody = {
    index: index,
    type: ESType.doc
  };
  const body = {
    query: {
      bool: {
        must: {
          match: {
            name: keyword
          }
        }
      }
    }
  };
  if (count !== undefined) {
    body.size = count;
  }
  if (page !== undefined) {
    body.from = page * count;
  }
  body.sort = [{ _score: "desc" }];
  reqBody.body = body;
  return esClient.search(reqBody);
};

/**
 * 查找并整理数据
 * @function eslasticCondition
 * @param {*} esBody
 * @param {String} esBody.keyword
 * @returns {Object<Number, Array>}
 */
async function eslasticCondition(esBody) {
  let docIds = [],
    total = 0;
  const es = await exports.searchESDocs(
    config.docESIndex,
    esBody.keyword,
    0,
    10000
  );
  total = es.hits.total;
  docIds = es.hits.hits.map(doc => doc._id);
  return {
    total,
    docIds
  };
}

/**
 * 整理文档查找条件
 * @function setDocCondition
 * @param {<Module: FModels.Document>} esBody
 * @returns {*}
 */
async function setDocCondition(esBody) {
  const condition = {};
  esBody = esBody || {};
  if (esBody.startTime && esBody.endTime) {
    const { startTime, endTime } = esBody;
    condition.$and = [
      { createTime: { $lte: new Date(endTime) } },
      { createTime: { $gte: new Date(startTime) } }
    ];
  }
  if (esBody.state) condition.state = esBody.state;
  if (esBody.tagId) condition.tagId = ObjectId(esBody.tagId);
  if (esBody.deptId) condition.deptId = ObjectId(esBody.deptId);
  if (esBody.category) condition.category = esBody.category;
  if (esBody.type) condition.type = esBody.type;
  if (esBody.signatory) condition.signatory = esBody.signatory;
  if (esBody.currencyUnit) condition.currencyUnit = esBody.currencyUnit;
  if (esBody.dealine) {
    const now = new Date().getTime();
    const duration = +esBody.dealine * 30 * 24 * 3600 * 1000;
    condition.endTime = { $lte: new Date(now + duration) };
  }
  if (esBody.keyword) {
    let docIdQuery = [];
    const { total, docIds } = await eslasticCondition(esBody);
    if (total === 0 || docIds.length === 0) return { _id: null };
    docIds.forEach(docId => {
      docIdQuery.push({ _id: ObjectId(docId) });
    });
    condition.$or = docIdQuery;
  }
  return condition;
}

/**
 * 查找文档
 * @function searchDocs
 * @param {Object} esBody
 * @returns {*}
 */
exports.searchDocs = async esBody => {
  const limit = +esBody.count || 20;
  const skip = (+esBody.page || 0) * limit;
  const condition = await setDocCondition(esBody);
  const docs = await Doc.find(condition)
    .skip(skip)
    .limit(limit)
    .sort({ createTime: -1 });
  return await formatDoc(docs);
};

/**
 * 根据id查找文档
 * @function searchDocById
 * @param {ObjectId} docId
 * @returns {*}
 */
exports.searchDocById = async docId => {
  return await Doc.findById(docId);
};

/**
 * 格式化文档，补充部门信息等内容(这个部门不是直属部门,是第三层级的部门)
 * @function formatDoc
 * @param {Array} docs
 * @returns {*}
 */
async function formatDoc(docs) {
  let deptName;
  const deptIds = docs.map(doc => doc.deptId);
  if (deptIds.length === 0) return [];
  const deptQuery = [];
  deptIds.forEach(deptId => {
    deptQuery.push({ _id: deptId });
  });
  const depts = await Dept.find({ $or: deptQuery });
  const deptMap = FUtil.hashMap(depts, "_id");
  return docs.map(doc => {
    if (doc.toObject) doc = doc.toObject();
    deptName =
      (deptMap[`${doc.deptId}`] && deptMap[`${doc.deptId}`].name) || "";
    doc.deptName = deptName;
    return doc;
  });
}

/**
 * 聚合查询(总的文档数,总的金额)
 * @function aggregateDetails
 * @param {Object} condition
 * @returns {*}
 */
async function aggregateDetails(condition) {
  let totalCount = 0,
    totalAmount = 0;
  const docs = await Doc.aggregate([
    { $match: condition },
    {
      $group: {
        _id: "$currencyUnit",
        count: { $sum: 1 },
        amount: { $sum: "$contractMoney" }
      }
    }
  ]);
  docs.forEach(doc => {
    totalCount += doc.count;
    totalAmount += doc.amount;
  });
  return {
    totalCount,
    totalAmount,
    details: docs
  };
}

exports.countDocs = async esBody => {
  const condition = await setDocCondition(esBody);
  return await aggregateDetails(condition);
};

/**
 * 上传文档
 * @function storeFile
 * @param {Object} storageBody
 * @param {String} storageBody.uid 上传者
 * @param {module<FEnum.StorageType || Number>}  storage 存储类型
 * @param {moduel<FEnum.StorageDirType> || String} dir 所存的文件夹位置路径
 * @param {String} file 本地文件地址(待上传文件)
 * @returns {Boolean}
 */
exports.storeFile = async storageBody => {
  const { uid, storage, dir, path, name } = storageBody;
  const smbConfigure = await systemProxy.getSmbSet();
  if (!smbConfigure || !smbConfigure.share) return false;
  if (storage === FEnum.StorageType.smb) {
    const folder = await FSmb(smbConfigure).exists(dir);
    if (folder instanceof Error) return false;
    if (folder.link && !folder.exist) {
      await FSmb(smbConfigure).createFolder(dir);
    }
    const format = name.split(".")[name.split(".").length - 1];
    const timestamp = new Date().getTime();
    const avatarPath = `${dir}\\${uid}_${timestamp}.${format}`;
    await FSmb(smbConfigure).uploadFile({ path, name: avatarPath });
    return avatarPath;
  }
};

/**
 * 下载文档
 * @function acquireFile
 * @param {String} path 文件存储在smb的具体位置,如 avatars\\abc.jpg
 * @returns {Object} buffer
 * @return {String} buffer.filename
 * @return {Buffer} buffer.buffer
 */
exports.acquireFile = async path => {
  const smbConfigure = await systemProxy.getSmbSet();
  if (!smbConfigure) return {};
  const buffer = await FSmb(smbConfigure).downloadFile(path);
  if (buffer instanceof Error) return false;
  return buffer;
};

/**
 * 创建文档
 * @function createDoc
 * @param {Object} postBody
 * @returns {*}
 */
exports.createDoc = async postBody => {
  const { uid } = postBody || {};
  const user = await User.findById(uid);
  if (!user) throw FError.NotFoundUser("not found user");
  const { deptId } = user;
  const dept = await deptProxy.getPatrDept(deptId, config.rootDept.level + 2);
  if (!dept) throw FError.NotFoundDept("not found dept");
  const doc = await new Doc({ ...postBody, deptId: dept._id }).save();
  await exports.indexESDoc(config.docESIndex, doc);
  return doc;
};

/**
 * @function updateDoc
 * @param {ObjectId} docId
 * @param {Object} putBody
 * @returns {Boolean}
 */
exports.updateDoc = async (docId, putBody) => {
  const doc = await Doc.findById(docId);
  if (!doc) return false;
  const docStates = [FEnum.DocumentState.making, FEnum.DocumentState.reject];
  if (!docStates.includes(+doc.state)) {
    return false;
  }
  const { deptId, name } = putBody;
  if (deptId !== doc.deptId.toString()) return false;
  await Doc.updateOne({ _id: docId }, { $set: putBody });
  await exports.deleteESDoc(config.docESIndex, docId);
  await exports.indexESDoc(config.docESIndex, { _id: docId, name });
  return true;
};

/**
 * @function deleteDoc
 * @param {ObjectId} docId
 * @returns {*}
 */
exports.deleteDoc = async docId => {
  const doc = await Doc.findById(docId);
  if (!doc) return false;
  const docStates = [
    FEnum.DocumentState.making,
    FEnum.DocumentState.reject,
    FEnum.DocumentState.denied
  ];
  if (!docStates.includes(+doc.state)) {
    return false;
  }
  await exports.deleteESDoc(config.docESIndex, docId);
  return await Doc.findByIdAndDelete(docId);
};

/**
 * 查询签约方
 * @function aggreagteSignatory
 * @returns {Array}
 */
exports.aggreagteSignatory = async () => {
  const signatory = await Doc.aggregate([{ $group: { _id: "$signatory" } }]);
  return signatory.filter(sig => sig && sig._id);
};

/**
 * 获取我的文档中待处理的文档
 * @function acquireDealtDocs 
 * @param {ObjectId} uid
 * @param {Object} docBody
 * @returns {Array}
 */
exports.acquireDealtDocs = async (uid, docBody) => {
  docBody = docBody || {};
  const limit = +docBody.count || 20;
  const skip = (+docBody.page || 0) * limit;
  const docLogs = await DocLog.find({
    resUid: uid,
    status: true,
    resOptState: FEnum.OptState.dealing
  });
  if (docLogs.length === 0) return [];
  const docMaps = FUtil.hashMap(docLogs, "docId");
  const docIds = docLogs.map(doc => doc.docId);
  let condition = await setDocCondition(docBody);
  const docs = await Doc.find(
    Object.assign({}, condition, { _id: { $in: docIds } })
  )
    .skip(skip)
    .limit(limit)
    .sort({ createTime: -1 });
  return docs.map(doc => {
    doc = FUtil.mongoToObject(doc);
    doc.resOptType = docMaps[`${doc._id}`].resOptType;
    return doc;
  });
};

/**
 * 计数我的文档中待处理的文档
 * @function acquireDealtDocs 
 * @param {ObjectId} uid
 * @param {Object} docBody
 * @returns {*}
 */
exports.countDealtDocs = async (uid, docBody) => {
  docBody = docBody || {};
  const docs = await DocLog.find({
    resUid: uid,
    status: true,
    resOptState: FEnum.OptState.dealing
  });
  if (docs.length === 0) return [];
  const docIds = docs.map(doc => doc.docId);
  let condition = await setDocCondition(docBody);
  condition = Object.assign({}, condition, { _id: { $in: docIds } });
  return await aggregateDetails(condition);
};

/**
 * 获取我的文档中做成中的文档
 * @function acquireDealtDocs 
 * @param {ObjectId} uid
 * @param {Object} docBody
 * @returns {Array}
 */
exports.acquireMakingDocs = async (uid, docBody) => {
  docBody = docBody || {};
  const limit = +docBody.count || 20;
  const skip = (+docBody.page || 0) * limit;
  let condition = await setDocCondition(docBody);
  const { making, reject } = FEnum.DocumentState;
  return await Doc.find(
    Object.assign({}, condition, {
      state: { $in: [making, reject] },
      uid
    })
  )
    .skip(skip)
    .limit(limit)
    .sort({ createTime: -1 });
};

/**
 * 计数我的文档中做成中的文档
 * @function acquireDealtDocs 
 * @param {ObjectId} uid
 * @param {Object} docBody
 * @returns {*}
 */
exports.countMakingDocs = async (uid, docBody) => {
  docBody = docBody || {};
  const { making, reject } = FEnum.DocumentState;
  let condition = await setDocCondition(docBody);
  condition = Object.assign({}, condition, {
    state: { $in: [making, reject] },
    uid
  });
  return await aggregateDetails(condition);
};

/**
 * 获取我的文档中我创建的文档
 * @function acquireDealtDocs 
 * @param {ObjectId} uid
 * @param {Object} docBody
 * @returns {Array}
 */
exports.acquireCreatedDocs = async (uid, docBody) => {
  docBody = docBody || {};
  const limit = +docBody.count || 20;
  const skip = (+docBody.page || 0) * limit;
  let condition = await setDocCondition(docBody);
  const docs = await Doc.find(Object.assign({}, condition, { uid }))
    .skip(skip)
    .limit(limit)
    .sort({ createTime: -1 });
  return docs.map(doc => {
    doc = FUtil.mongoToObject(doc);
    doc.reqOptType = getReqOptType(doc);
    return doc;
  });
};

/**
 * 计数我的文档中为我创建的的文档
 * @function acquireDealtDocs 
 * @param {ObjectId} uid
 * @param {Object} docBody
 * @returns {*}
 */
exports.countCreatedDocs = async (uid, docBody) => {
  docBody = docBody || {};
  let condition = await setDocCondition(docBody);
  condition = Object.assign({}, condition, { uid });
  return await aggregateDetails(condition);
};

function getReqOptType(doc) {
  let reqOptType;
  const { state, type } = doc || {};
  const { foreginTrustee } = FEnum.DocumentType;
  switch (state) {
    case FEnum.DocumentState.sealed:
      reqOptType =
        type === foreginTrustee
          ? FEnum.ReqOptType.tax
          : FEnum.ReqOptType.archive;
      break;
    default:
      break;
  }
  return reqOptType;
}

/**
 * @function getOptRecords
 * @param {ObjectId} docId
 * @param {Number} type
 * @returns {*}
 */
exports.getOptRecords = async (docId, type) => {
  const { lent, archived } = FEnum.DocumentState;
  const { finished, dealing } = FEnum.OptState;
  const { back, lend } = FEnum.ResOptType;
  let records = [];
  let docLogs = await DocLog.find({ docId, status: true });
  switch (type) {
    case FEnum.RecordType.lend:
      const doc = await Doc.findById(docId);
      if (!doc || ![lent, archived].includes(doc.state)) records = [];
      records = docLogs.filter(
        docLog =>
          docLog.resOptState === finished &&
          [lend, back].includes(docLog.resOptType)
      );
      break;
    case FEnum.RecordType.review:
      docLogs = docLogs.filter(
        docLog => ![lend, back].includes(docLog.resOptType)
      );
      records = docLogs.map((docLog, index) => {
        docLog = FUtil.mongoToObject(docLog);
        if (index !== 0) {
          if (index === docLogs.length - 1) {
            if (docLog.resOptState === finished) docLog.isTurn = true;
          }
          let preLog = docLogs[index - 1];
          if (preLog.resOptType === finished && docLog.resOptState === dealing)
            docLog.isTurn = true;
        } else {
          if (docLog.resOptState === dealing) docLog.isTurn = true;
        }
      });
      records = docLogs;
      break;
    default:
      break;
  }
  return records;
};
