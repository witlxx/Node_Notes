"use strict";

exports.deptProxy = require("./deptProxy");
exports.docProxy = require("./docProxy");
exports.processProxy = require("./processProxy");
exports.ruleProxy = require("./ruleProxy");
exports.systemProxy = require("./systemProxy");
exports.userProxy = require("./userProxy");
exports.tagProxy = require("./tagProxy");
