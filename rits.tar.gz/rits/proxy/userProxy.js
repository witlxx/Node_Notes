"use strict";
const bcrypt = require("bcrypt");
const jsonwebtoken = require("jsonwebtoken");
const config = require(process.env.config);
const UUIDV4 = require("uuid/v4");
const { models: FModels, redis: RedisClient } = require("../connect");
const { User, Department: Dept, SystemSet: System } = FModels;
const { FUtil, FEnum, FMail } = require("../util");
const deptProxy = require("./deptProxy");
const { postUser } = require("../netSchema/userSchema");
const PWDExpireTime = 5 * 60 * 1000;

exports.searchUserByIdAndUpdate = async (uid, updateBy) => {
  return await User.findByIdAndUpdate(uid, { $set: updateBy });
};

exports.validateAdmin = async uid => {
  if (!uid || !FUtil.checkObjectId(uid)) return false;
  const user = await User.findById(uid);
  return (
    user && user.isAdmin === true && user.status === FEnum.UserStatus.enable
  );
};

exports.findById = async uid => {
  if (!uid || !FUtil.checkObjectId(uid)) return false;
  return await User.findOne({
    _id: uid,
    status: FEnum.UserStatus.enable
  });
};

exports.findOneByAccount = async account => {
  if (!account) return false;
  return await User.findOne({
    account: account,
    status: FEnum.UserStatus.enable
  });
};

exports.validateLogin = async userQuery => {
  let user = await exports.findOneByAccount(userQuery.account);
  if (!user) return false;
  const validatePass = bcrypt.compareSync(userQuery.password, user.password);
  if (!validatePass) return {};
  const dept = await Dept.findById(user.deptId);
  user = FUtil.mongoToObject(user);
  user.deptName = dept && dept.name;
  return Object.assign({}, user, {
    token: jsonwebtoken.sign(
      { data: user, exp: Math.floor(Date.now() / 1000) + 120 * 60 },
      config.aeskey.secret
    )
  });
};

exports.createUser = async userBody => {
  const { email, account, deptId, permissions } = userBody;
  const dept = await Dept.findById(deptId);
  if (
    !dept ||
    (permissions.includes(FEnum.UserAccess.seal) && !dept.isSealDept)
  )
    return {};
  const users = await User.find({
    $or: [{ email: email }, { account: account }]
  });
  if (users.length > 0) {
    if (users.map(user => user.status).includes(FEnum.UserStatus.enable))
      return false;
    await User.deleteMany({
      _id: { $in: users.map(user => user._id) },
      status: FEnum.UserStatus.disable
    });
  }
  return await new User(userBody).save();
};

/**
 * 1. email应该唯一
 * 2. account不可更改
 * 3. email可以不改
 */
exports.updateUser = async (uid, userBody) => {
  const { account, deptId, email, permissions } = userBody;
  const dept = await Dept.findById(deptId);
  if (
    !dept ||
    (permissions.includes(FEnum.UserAccess.seal) && !dept.isSealDept)
  )
    return {};
  const users = await User.find({
    $or: [{ _id: uid }, { email: email }],
    status: FEnum.UserStatus.enable
  });
  if (users.length > 1) return false;
  if (users[0].account !== account) return false;
  return await User.findOneAndUpdate(
    { _id: uid, account: account, status: FEnum.UserStatus.enable },
    { $set: userBody }
  );
};

exports.disableUser = async uid => {
  return await User.findByIdAndUpdate(uid, {
    $set: { status: FEnum.UserStatus.disable }
  });
};

async function queryCondition(userQuery) {
  const { keyword } = userQuery;
  let condition = keyword
    ? {
        $or: [
          { account: new RegExp(keyword, "i") },
          { email: new RegExp(keyword, "i") }
        ]
      }
    : {};
  condition.status = FEnum.UserStatus.enable;
  return condition;
}

exports.countUsers = async userQuery => {
  const condition = await queryCondition(userQuery);
  return await User.countDocuments(condition);
};

async function formatUser(users) {
  let deptName;
  const deptIds = users.map(user => user.deptId);
  if (deptIds.length === 0) return [];
  const deptQuery = [];
  deptIds.forEach(deptId => {
    deptQuery.push({ _id: deptId });
  });
  const depts = await Dept.find({ $or: deptQuery });
  const deptMap = FUtil.hashMap(depts, "_id");
  return users.map(user => {
    if (user.toObject) user = user.toObject();
    deptName =
      (deptMap[`${user.deptId}`] && deptMap[`${user.deptId}`].name) || "";
    user.deptName = deptName;
    return user;
  });
}

exports.searchUsers = async userQuery => {
  const limit = +userQuery.count || 20;
  const skip = (+userQuery.page || 0) * limit;
  const condition = await queryCondition(userQuery);
  const users = await User.find(condition)
    .skip(skip)
    .limit(limit)
    .sort({ createTime: -1 });
  return await formatUser(users);
};

/**
 * 获取level等级的所有同事(如果获取公司下的一级部门的人, level = 2)
 * 但是不允许用此接口查询此公司的所有人，level !== 1
 * @function getColleagues
 * @param {ObjectId} uid
 * @param {Number} level
 * @returns {Array}
 */
exports.getColleagues = async (uid, level) => {
  if (level === config.rootDept.level) return [];
  const user = await User.findById(uid);
  if (!user || user.status === FEnum.UserStatus.disable) return false;
  const parent = await deptProxy.getPatrDept(user.deptId, level);
  if (!parent) return [];
  const parentId = parent._id;
  const deptIds = await deptProxy.getKinDeptIds(parentId);
  const condition = [];
  deptIds.forEach(deptId => {
    condition.push({ deptId: deptId });
  });
  return await User.find({
    $or: condition,
    status: FEnum.UserStatus.enable
  });
};

exports.mailValidate = async userBody => {
  const verification = UUIDV4();
  const { account, email } = userBody;
  const user = await User.findOne({ account: account, email: email });
  if (!user) return false;
  const key = FEnum.RedisKey.passBack.format(userBody);
  const verify = await RedisClient.get(key);
  if (!verify) {
    await RedisClient.multi()
      .setnx(key, verification)
      .pexpire(key, PWDExpireTime)
      .exec();
    const smtp = await System.findOne({ setType: FEnum.SetType.email });
    if (!smtp) return false;
    const { host, port, secure, user: login, pass, sender } = smtp.content;
    const text = bcrypt.hashSync(
      `account=${account}&email=${email}&type=${
        FEnum.PassUpdMethod.email
      }&verification=${verification}`,
      5
    );
    await FMail.sendMail(
      { host, port, secure },
      login || pass ? { user: login, pass } : null,
      `"${sender}" <${sender}>`,
      email,
      "[rits.文档管理系统]密码找回",
      { text: config.domain + `?code=${text}` }
    );
  }
  return true;
};

exports.updatePass = async userBody => {
  const { type, account, email, originPass, newPass, verification } = userBody;
  const types = Object.values(FEnum.PassUpdMethod);
  if (!types.includes(type)) return false;

  const user = await User.findOne({ account: account, email: email });
  if (!user) return false;

  if (type === FEnum.PassUpdMethod.email) {
    const key = FEnum.RedisKey.passBack.format(userBody);
    const verify = await RedisClient.get(key);
    if (!verify || verification !== verify) return false;
  }
  if (type === FEnum.PassUpdMethod.reset) {
    const validate = await bcrypt.compareSync(originPass, user.password);
    if (!validate) return false;
  }
  return await User.updateOne(
    { account, email, status: FEnum.UserStatus.enable },
    { $set: { password: bcrypt.hashSync(newPass, 5) } }
  );
};

exports.updateUserData = async (uid, selfBody) => {
  const { email, agentUid, account } = selfBody;
  const users = await User.find({
    $or: [{ _id: uid }, { email: email }],
    status: FEnum.UserStatus.enable
  });
  if (users.length > 1) return {};
  if (users[0].account !== account) return {};
  if (agentUid) {
    const agent = await User.findById(agentUid);
    if (!agent || agent.status !== FEnum.UserStatus.enable) return {};
  }
  return await User.findOneAndUpdate(
    { _id: uid, status: FEnum.UserStatus.enable },
    { $set: { email, agentUid } }
  );
};

exports.findUsers = async condition => {
  condition = condition || {};
  return await User.find(condition);
};

exports.csvLoadUsers = async userLists => {
  const schemas = [];
  let userSchema = {},
    line = 0;
  if (userLists.length === 0) return false;
  const keys = userLists[0];
  for (let j = 1; j < userLists.length; j++) {
    let user = userLists[j];
    for (let i = 0; i < keys.length; i++) {
      userSchema[`${keys[i]}`] = user[i];
      schemas.push(userSchema);
    }
    if (!FUtil.reqVerify(schemas[j], postUser)) {
      line = j;
      break;
    }
  }
  if (line === 0) {
    await Dept.insertMany(schemas);
    return { count: userLists.length - 1 };
  } else {
    return { errorLine: line };
  }
};
