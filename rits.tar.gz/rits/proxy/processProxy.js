"use strict";
const config = require(process.env.config);
const FModels = require("../connect").models;
const {
  DocumentLog: DocLog,
  Document: Doc,
  Department: Dept,
  SystemSet: System,
  User,
  Rule
} = FModels;
const deptProxy = require("../proxy/deptProxy");
const { FEnum, FUtil, FMail } = require("../util");
const _ = require("lodash");

/**审核路径 */
async function formatAuditLines(rule, specUsers) {
  const auditLines = await exports.getAuditLines(rule, specUsers);
  return await exports.agentFormatula(auditLines);
}

/**盖章路径(审核后) */
async function formatSeaLines(dept, multiple, rule, specUsers) {
  const [sealers, bscLeader] = await exports.getBscUsers(dept, multiple);
  const sealLines = await exports.getSealLines(
    rule,
    specUsers,
    sealers,
    bscLeader
  );
  return await exports.agentFormatula(sealLines);
}

/**直接保存路径(审核后) */
async function formatKeepLins(dept) {
  const [sealers] = await exports.getBscUsers(dept);
  const keepLines = await exports.getKeepLines(sealers);
  return await exports.agentFormatula(keepLines);
}

/**盖章完请求直接存档路径 */
async function formatArchiveLines(dept) {
  const [sealers] = await exports.getBscUsers(dept);
  const archiveLines = await exports.getArchiveLines(sealers);
  return await exports.agentFormatula(archiveLines);
}

/**盖完章请求免税处理,然后存档 */
async function formatTaxLines(dept) {
  const [sealers, , taxers] = await exports.getBscUsers(dept);
  const taxLines = await exports.getTaxLines(taxers, sealers);
  return await exports.agentFormatula(taxLines);
}

exports.acquirePaths = async (pathBody, user) => {
  let auditLines = [],
    sealLines = [],
    keepLines = [],
    taxLines = [],
    archiveLines = [];
  const { reqOptType, documentCategory: category, multiple } = pathBody;
  const rule = await Rule.findOne({ category });
  const dept = await Dept.findById(user.deptId);
  if (!rule || !dept) return false;
  switch (reqOptType) {
    case FEnum.ReqOptType.archive:
      archiveLines = await formatArchiveLines(dept);
      break;
    case FEnum.ReqOptType.tax:
      taxLines = await formatTaxLines(dept);
      break;
    default:
      const specUsers = await exports.getSupLeader(user, dept);
      auditLines = await formatAuditLines(rule, specUsers);
      if (reqOptType === FEnum.ReqOptType.seal) {
        sealLines = await formatSeaLines(dept, multiple, rule, specUsers);
      }
      if (reqOptType === FEnum.ReqOptType.keep) {
        keepLines = await formatKeepLins(dept);
      }
      break;
  }
  return { auditLines, sealLines, keepLines, taxLines, archiveLines };
};

/**
 * 获取user的所有直系上级路径(课长->部长->中心长->总经理)
 */
const jobPath = length => Array.from({ length }).map((v, k) => k + 1);
exports.getSupLeader = async (user, dept) => {
  let deptPath = [],
    specUsers = [],
    deptMap = [];
  const level = +dept.level;
  const jobLevels = jobPath(level)
    .filter(lv => {
      return user.isLeader ? lv < level : lv <= level;
    })
    .reverse();
  jobLevels.forEach(lv => {
    deptPath.push(deptProxy.getPatrDept(user.deptId, lv));
  });
  deptPath = await Promise.all(deptPath);
  deptMap = FUtil.hashMap(deptPath, "_id");
  deptPath.forEach(dept => {
    if (dept)
      specUsers.push(User.findOne({ deptId: dept._id, isLeader: true }));
  });
  specUsers = await Promise.all(specUsers);
  return specUsers.map(specUser => {
    if (specUser) {
      specUser = FUtil.mongoToObject(specUser);
      let key = specUser.deptId.toString();
      specUser.level = deptMap[`${key}`].level;
      return specUser;
    }
  });
};

/**
 * 获取bsc中心长和盖章处理者
 */
exports.getBscUsers = async (dept, multiple) => {
  /**查找bsc合同盖章担当和免税处理担当 */
  const { taxer, bscSealer, sealer } = FEnum.UserRole;
  const sealCondition = dept.isSealDept
    ? { roles: bscSealer }
    : { roles: sealer };
  const queryResults = await User.find({
    $or: [{ roles: taxer }, sealCondition]
  });
  /**盖章担当 */
  let sealers = queryResults.filter(
    user => user.roles.includes(bscSealer) || user.roles.includes(sealer)
  );
  sealers = multiple ? sealers : new Array(sealers[0]);
  /**免税处理担当 */
  const taxers = queryResults.filter(user => user.roles.includes(taxer));
  /**查找bsc中心长 */
  const bscCenter = await Dept.findOne({
    level: config.rootDept.level + 1,
    isSealDept: true
  });
  const bscLeader = await User.findOne({
    status: FEnum.UserStatus.enable,
    isLeader: true,
    deptId: bscCenter && bscCenter._id
  });
  return [sealers, bscLeader, taxers];
};

exports.getAuditLines = async (rule, leaders) => {
  const auditLines = [];
  const { auditPath } = rule;
  auditPath.forEach(audit => {
    auditLines.push(
      leaders.filter(leader => leader && leader.level === audit.level)[0]
    );
  });
  return auditLines
    .filter(auditLine => auditLine)
    .map(audit => {
      if (audit) {
        audit = FUtil.mongoToObject(audit);
        audit.resOptType = FEnum.ResOptType.audit;
        return audit;
      }
    });
};

exports.getSealLines = async (rule, leaders, sealers, bscLeader) => {
  if (sealers.length === 0) return [];
  /**拼接盖章处理者 */
  sealers = sealers.map(seal => {
    seal = FUtil.mongoToObject(seal);
    seal.resOptType = FEnum.ResOptType.accept;
    return seal;
  });
  const sealLines = sealers;
  const { sealPath } = rule;
  /**拼接各级领导 */
  leaders = leaders.map(leader => {
    if (leader) {
      leader = FUtil.mongoToObject(leader);
      leader.resOptType = FEnum.ResOptType.seal;
      return leader;
    }
  });
  sealPath.forEach(seal => {
    sealLines.push(
      leaders.filter(
        leader =>
          leader &&
          leader.level === seal.level &&
          leader.level !== config.rootDept.level + 1
      )[0]
    );
  });
  /**拼接bsc中心长和bsc盖章处理者 */
  sealPath.forEach(seal => {
    const validateBsc = seal.level === config.rootDept.level + 1;
    const validateSeal = [
      FEnum.UserRole.bscSealer,
      FEnum.UserRole.sealer
    ].includes(seal.role);
    if (validateBsc && bscLeader) {
      bscLeader = FUtil.mongoToObject(bscLeader);
      bscLeader.resOptType = FEnum.ResOptType.seal;
      bscLeader.level = config.rootDept.level + 1;
      sealLines.push(bscLeader);
    }
    if (validateSeal && sealers.length > 0) {
      let finalSealer = sealers[0];
      finalSealer.resOptType = FEnum.ResOptType.seal;
      sealLines.push(finalSealer);
    }
  });
  return sealLines.filter(sealLine => sealLine);
};

exports.getKeepLines = async sealers => {
  if (sealers.length === 0) return [];
  let sealer = FUtil.mongoToObject(sealers[0]);
  sealer.resOptType = FEnum.ResOptType.archive;
  return [sealer];
};

exports.getArchiveLines = async archivers => {
  if (archivers.length === 0) return [];
  let archiver = FUtil.mongoToObject(archivers[0]);
  archiver.resOptType = FEnum.ResOptType.archive;
  return [archiver];
};

exports.getTaxLines = async (taxers, sealers) => {
  if (taxers.length === 0 || sealers.length === 0) return [];
  let taxer = FUtil.mongoToObject(taxers[0]);
  taxer.resOptType = FEnum.ResOptType.tax;
  let sealer = FUtil.mongoToObject(sealers[0]);
  sealer.resOptType = FEnum.ResOptType.archive;
  return [sealer, taxer];
};

exports.agentFormatula = async users => {
  const agentUsers = await User.find({
    _id: { $in: users.map(user => user.agentUid) }
  });
  const agentUserMap = FUtil.hashMap(agentUsers, "_id");
  return users.map(user => {
    return {
      name: user.name,
      uid: user._id,
      agentUid: user.agentUid,
      agentName: user.agentUid ? agentUserMap[`${user.agentUid}`].name : null,
      resOptType: user.resOptType,
      level: user.level,
      isLeader: user.isLeader,
      deptId: user.deptId
    };
  });
};
/**-------------------------以上为匹配路径逻辑------------------------- */

/**-------------------------以下为触发路径逻辑------------------------- */
exports.litProcess = async logBody => {
  let docLogs = [];
  const { paths } = logBody || {};
  if (!Array.isArray(paths) || paths.length === 0) return [];
  delete logBody.paths;
  paths.map(item => {
    docLogs.push(Object.assign({}, item, logBody));
  });
  const handler = await exports.notifyHandler(
    docLogs[0],
    FEnum.MailContentType.optNeed
  );
  if (!handler) return false;
  let limit = false;
  switch (logBody.reqOptType) {
    case FEnum.ReqOptType.seal:
    case FEnum.ReqOptType.keep:
      limit = await FUtil.reqOptLimit(logBody.docId, FEnum.ReqOptType.seal);
      break;
    case FEnum.ReqOptType.tax:
      limit = await FUtil.reqOptLimit(logBody.docId, FEnum.ReqOptType.tax);
      break;
    case FEnum.ReqOptType.archive:
      limit = await FUtil.reqOptLimit(logBody.docId, FEnum.ReqOptType.archive);
      break;
    default:
      break;
  }
  if (!limit) return false;
  /**激活第一个人的待处理状态 */
  docLogs[0].resOptState = FEnum.OptState.dealing;
  return await DocLog.insertMany(docLogs);
};

/**
 * email通知用户去处理
 * @function notifyHandler
 * @params {Object} optUser
 * @param {String} optUser.docName
 * @param {ObjectId} optUser.resUid 操作者uid
 * @param {String} optUser.resName  操作者名称
 * @param {<module: FEnum.resOptType>} optUser.resOptType 被请求的操作
 * @param {Boolean} optUser.emergency 是否紧急
 * @param {Date} optUser.deadline 希望纳期
 * @return {*}
 */
exports.notifyHandler = async (optUser, mailType) => {
  const { optNeed } = FEnum.MailContentType;
  const { resUid, reqUid } = optUser || {};
  const uid = mailType === optNeed ? resUid : reqUid;
  const user = await User.findById(uid);
  if (!user || !user.email) return false;
  const smtp = await System.findOne({ setType: FEnum.SetType.email });
  const { host, port, secure, user: login, pass, sender } =
    (smtp && smtp.content) || {};
  const title =
    mailType === optNeed
      ? "[rits.文档管理系统]请求操作"
      : "[rits.文档管理系统]审核通知";
  const text =
    mailType === optNeed
      ? exports.resMailText(optUser)
      : exports.notifyMailText(optUser);
  return await FMail.sendMail(
    { host, port, secure },
    login || pass ? { user: login, pass } : null,
    `"${sender}" <${sender}>`,
    user.email,
    title,
    { text }
  );
};

/**
 * 请求操作生成邮件文本
 * @function resMailText
 * @param {Object} optUser
 * @param {String} optUser.docName
 * @param {String} optUser.resName  操作者名称
 * @param {<module: FEnum.resOptType>} optUser.resOptType 被请求的操作
 * @param {Boolean} optUser.emergency 是否紧急
 * @param {Date} optUser.deadline 希望纳期
 */
exports.resMailText = optUser => {
  let { docName, resName, resOptType, emergency, deadline } = optUser || {};
  let text =
    "尊敬的{resName}: \n  " +
    "您好! \n  " +
    "文档{docName}需要您{resOptCN}. \n  " +
    "紧急程度: {emergency} \n  " +
    "希望纳期: {deadline}\n  " +
    "时间:{now}";
  const { ResOptCN, ResOptType } = FEnum;
  const cnKey = Object.keys(ResOptType).filter(
    key => ResOptType[`${key}`] === resOptType
  )[0];
  const resOptCN = ResOptCN[`${cnKey}`];
  emergency = emergency ? "紧急" : "不紧急";
  deadline = deadline ? FUtil.formatDate(deadline) : "无";
  const now = FUtil.formatDate(new Date());
  return text.format({ resName, docName, resOptCN, emergency, deadline, now });
};

/**
 * 通知邮件生成文本
 * @function notifyMailText
 * @param {Object} optUser
 * @param {String} optUser.docName
 * @param {String} optUser.reqName
 * @param {Number} optUser.docState
 * @return {*}
 */
exports.notifyMailText = optUser => {
  const { docName, reqName, docState } = optUser;
  let text =
    "尊敬的{reqName}: \n  " +
    "您好!\n  " +
    "您的文档{docName} \n  " +
    "目前的审批状态为{docStateCN} \n  " +
    "时间:{now}";
  const { DocumentState, DocumentStateCN } = FEnum;
  const cnKey = Object.keys(DocumentState).filter(
    key => DocumentState[`${key}`] === docState
  )[0];
  const docStateCN = DocumentStateCN[`${cnKey}`];
  const now = FUtil.formatDate(new Date());
  return text.format({ reqName, docName, docStateCN, now });
};

/**
 * 涉及到多人操作,所以分过程中的角色
 * enum for processRole
 * @enum {Number}
 */
const processRole = {
  none: 0 /**角色初始化,不对应任何操作 */,
  first: 1 /**第一个操作者 */,
  processing: 2 /**过程中的操作者 */,
  last: 3 /**最后一个操作者 */
};

exports.lanuchOptProcess = async (uid, doc, resOptType, reqBody) => {
  const { lentBody, finalPos, archiveDir } = reqBody;
  doc = doc || {};
  const limit = await FUtil.resOptLimit(doc._id, resOptType);
  if (!limit) return limit;
  const resApi = exports.resOptFuncDealtMap[resOptType];
  if (!resApi) return false;
  return await resApi(uid, doc, lentBody, { finalPos, archiveDir });
};

exports.resAudit = async (resUid, doc) => {
  let proRole = processRole.none;
  const { preLog, myLog, susLog } = await searchAdjacentLog(doc._id, resUid);
  if (!myLog || !susLog) return false;
  const { audit } = FEnum.ResOptType;
  if (!preLog) proRole = processRole.first;
  if (myLog.resOptType === audit && susLog.resOptType === audit)
    proRole = processRole.processing;
  if (myLog.resOptType === audit && susLog.resOptType !== audit)
    proRole = processRole.last;
  return await lanuchAudit(proRole, { myLog, susLog });
};

async function lanuchAudit(proRole, resLogs) {
  const { myLog, susLog } = resLogs;
  const { finished, dealing } = FEnum.OptState;
  switch (proRole) {
    case processRole.first:
    case processRole.processing:
      await handleResOptState(myLog.docId, myLog.resUid, finished);
      await transferState(myLog.docId, FEnum.DocumentState.auditing);
      await handleResOptState(myLog.docId, susLog.resUid, dealing);
      await exports.notifyHandler(
        {
          resUid: susLog.resUid,
          docName: myLog.docName,
          resName: susLog.resName,
          resOptType: susLog.resOptType,
          emergency: susLog.emergency,
          deadline: susLog.deadline
        },
        FEnum.MailContentType.optNeed
      );
      break;
    case processRole.last:
      await handleResOptState(myLog.docId, myLog.resUid, finished);
      if (susLog.resOptType === FEnum.ResOptType.archive) {
        await transferState(myLog.docId, FEnum.DocumentState.archiving);
      } else {
        await transferState(myLog.docId, FEnum.DocumentState.accepting);
      }
      await handleResOptState(myLog.docId, susLog.resUid, dealing);
      await exports.notifyHandler(
        {
          resUid: susLog.resUid,
          docName: myLog.docName,
          resName: susLog.resName,
          resOptType: susLog.resOptType,
          emergency: susLog.emergency,
          deadline: susLog.deadline
        },
        FEnum.MailContentType.optNeed
      );
      break;
    default:
      break;
  }
  return true;
}

exports.resAccept = async (resUid, doc) => {
  let proRole = processRole.none;
  const { preLog, myLog, susLog } = await searchAdjacentLog(doc._id, resUid);
  if (!preLog || !myLog || !susLog) return false;
  const { audit, accept, seal } = FEnum.ResOptType;
  if (preLog.resOptType === audit && myLog.resOptType === accept)
    proRole = processRole.first;
  if (preLog.resOptType === accept && myLog.resOptType === accept)
    proRole = processRole.processing;
  if (myLog.resOptType === accept && susLog.resOptType === seal)
    proRole = processRole.last;
  return await lanuchAccept(proRole, { myLog, susLog });
};

async function lanuchAccept(proRole, resLogs) {
  const { myLog, susLog } = resLogs;
  const { finished, dealing } = FEnum.OptState;
  switch (proRole) {
    case processRole.first:
    case processRole.processing:
      await handleResOptState(myLog.docId, myLog.resUid, finished);
      await transferState(myLog.docId, FEnum.DocumentState.accepting);
      await handleResOptState(myLog.docId, susLog.resUid, dealing);
      await exports.notifyHandler(
        {
          resUid: susLog.resUid,
          docName: myLog.docName,
          resName: susLog.resName,
          resOptType: susLog.resOptType,
          emergency: susLog.emergency,
          deadline: susLog.deadline
        },
        FEnum.MailContentType.optNeed
      );
      break;
    case processRole.last:
      await handleResOptState(myLog.docId, myLog.resUid, finished);
      await transferState(myLog.docId, FEnum.DocumentState.sealing);
      await handleResOptState(myLog.docId, susLog.resUid, dealing);
      await exports.notifyHandler(
        {
          resUid: susLog.resUid,
          docName: myLog.docName,
          resName: susLog.resName,
          resOptType: susLog.resOptType,
          emergency: susLog.emergency,
          deadline: susLog.deadline
        },
        FEnum.MailContentType.optNeed
      );
      break;
    default:
      break;
  }
  return true;
}

exports.resSeal = async (resUid, doc) => {
  let proRole = processRole.none;
  const { preLog, myLog, susLog } = await searchAdjacentLog(doc._id, resUid);
  if (!preLog || !myLog) return false;
  const { accept, seal } = FEnum.ResOptType;
  if (preLog.resOptType === seal && myLog.resOptType === seal)
    proRole = processRole.processing;
  if (preLog.resOptType === accept && myLog.resOptType === seal)
    proRole = processRole.first;
  if (!susLog) proRole = processRole.last;
  return await lanuchSeal(proRole, { myLog, susLog });
};

async function lanuchSeal(proRole, resLogs) {
  const { myLog, susLog } = resLogs;
  const { finished, dealing } = FEnum.OptState;
  switch (proRole) {
    case processRole.first:
    case processRole.processing:
      await handleResOptState(myLog.docId, myLog.resUid, finished);
      await transferState(myLog.docId, FEnum.DocumentState.sealing);
      await handleResOptState(myLog.docId, susLog.resUid, dealing);
      await exports.notifyHandler(
        {
          resUid: susLog.resUid,
          docName: myLog.docName,
          resName: susLog.resName,
          resOptType: susLog.resOptType,
          emergency: susLog.emergency,
          deadline: susLog.deadline
        },
        FEnum.MailContentType.optNeed
      );
      break;
    case processRole.last:
      await handleResOptState(myLog.docId, myLog.resUid, finished);
      await transferState(myLog.docId, FEnum.DocumentState.sealed);
      await exports.notifyHandler(
        {
          reqUid: myLog.reqUid,
          docName: myLog.docName,
          reqName: myLog.reqName,
          docState: FEnum.DocumentState.sealed
        },
        FEnum.MailContentType.notification
      );
      break;
    default:
      break;
  }
  return true;
}

exports.resTax = async (resUid, doc) => {
  /**免税处理的过程中,免税担当处理完后必须为存档担当,所以myLog和susLog必须都存在 */
  const { myLog, susLog } = await searchAdjacentLog(doc._id, resUid);
  if (!myLog || !susLog) return false;
  const { finished, dealing } = FEnum.OptState;
  await handleResOptState(doc._id, resUid, finished);
  await transferState(doc._id, FEnum.DocumentState.archiving);
  await handleResOptState(doc._id, susLog.resUid, dealing);
  return await exports.notifyHandler(
    {
      resUid: susLog.resUid,
      docName: doc.name,
      resName: susLog.resName,
      resOptType: susLog.resOptType,
      emergency: susLog.emergency,
      deadline: susLog.deadline
    },
    FEnum.MailContentType.optNeed
  );
};

exports.resArchive = async (resUid, doc, __, archiveBody) => {
  const { finalPos, archiveDir } = archiveBody || {};
  const { archived } = FEnum.DocumentState;
  const { myLog } = await searchAdjacentLog(doc._id, resUid);
  if (!myLog) return false;
  const { finished } = FEnum.OptState;
  const docLog = await handleResOptState(doc._id, resUid, finished);
  await transferState(doc._id, archived, { finalPos, archiveDir });
  return await exports.notifyHandler(
    {
      reqUid: docLog.reqUid,
      docName: doc.name,
      reqName: docLog.reqName,
      docState: archived
    },
    FEnum.MailContentType.notification
  );
};

exports.resReject = async (resUid, doc) => {
  const { myLog } = await searchAdjacentLog(doc._id, resUid);
  if (!myLog) return false;
  const { finished } = FEnum.OptState;
  const docLog = await handleResOptState(doc._id, resUid, finished);
  await transferState(doc._id, FEnum.DocumentState.reject);
  await closeProcesses(doc._id);
  return await exports.notifyHandler(
    {
      reqUid: docLog.reqUid,
      docName: doc.name,
      reqName: docLog.reqName,
      docState: FEnum.DocumentState.reject
    },
    FEnum.MailContentType.notification
  );
};

exports.resDeny = async (resUid, doc) => {
  const { myLog } = await searchAdjacentLog(doc._id, resUid);
  if (!myLog) return false;
  const { finished } = FEnum.OptState;
  const docLog = await handleResOptState(doc._id, resUid, finished);
  await transferState(doc._id, FEnum.DocumentState.denied);
  await closeProcesses(doc._id);
  return await exports.notifyHandler(
    {
      reqUid: docLog.reqUid,
      docName: doc.name,
      reqName: docLog.reqName,
      docState: FEnum.DocumentState.denied
    },
    FEnum.MailContentType.notification
  );
};

/**
 * 转换操作者操作记录
 * @function handleResOptState
 * @param {ObjectId} docId
 * @param {ObjectId} resUid
 * @param {<Module: FEnum.ResOptState>} resOptState
 * @returns {*}
 */
async function handleResOptState(docId, resUid, resOptState) {
  return await DocLog.findOneAndUpdate(
    { docId, resUid, status: true },
    { $set: { resOptState, resOptTime: new Date() } }
  );
}

/**
 * 处理完之后更新文档的状态(更改FModels.Doc.state)
 * @function transferState
 * @param {ObjectId} docId
 * @param {<Module: FEnum.DocumentState>} state
 * @param {Object} update 其他需要更新的内容
 * @param {String} update.finalPos
 * @param {String} update.archiveDir
 * @returns {*}
 */
async function transferState(docId, state, update) {
  let updateBy = { state };
  if (update) {
    updateBy = Object.assign({}, updateBy, update);
  }
  return await Doc.findByIdAndUpdate(docId, { $set: updateBy });
}

/**
 * 否决(deny)或建议保留(reject)的状态下doclogs中的status更新为false
 * @function closeProcesses
 * @param {ObjectId} docId
 * @returns {*}
 */
async function closeProcesses(docId) {
  return await DocLog.updateMany({ docId }, { $set: { status: false } });
}

/**
 * 查询审核过程中的上一个人和下一个人
 * @function searchAdjacentLog
 * @param {ObjectId} docId
 * @param {ObjectId} resUid
 * @returns {*}
 */
async function searchAdjacentLog(docId, resUid) {
  let [preLog, myLog, susLog] = [false, false, false];
  const { finished, dealing, pending } = FEnum.OptState;
  const docLogs = await DocLog.find({ docId, status: true });
  const filterIndexes = docLogs.map((docLog, index) => {
    if (
      docLog.status /**文档没有被否掉 */ &&
      docLog.resUid.toString() === resUid /**是处理者本人 */ &&
      docLog.resOptState === dealing /**轮到处理者处理了 */
    )
      return index;
  });
  const indexes = filterIndexes.filter(i => !Number.isNaN(+i));
  if (indexes.length !== 1) return { preLog, myLog, susLog };
  const index = indexes[0];
  if (index !== 0) {
    preLog =
      docLogs[index - 1].resOptState === finished ? docLogs[index - 1] : false;
  }
  myLog = docLogs[index];
  if (index !== docLogs.length - 1) {
    susLog =
      docLogs[index + 1].resOptState === pending ? docLogs[index + 1] : false;
  }
  return { preLog, myLog, susLog };
}

exports.resLend = async (resUid, doc, lentBody) => {
  const { lentUid, startTime, endTime } = lentBody || {};
  const reqUser = await User.findById(lentUid);
  if (!reqUser) return false;
  await new DocLog({
    docId: doc._id,
    docName: doc.name,
    reqUid: reqUser._id,
    reqName: reqUser.name,
    resUid: resUid,
    resOptType: FEnum.ResOptType.lend,
    resOptState: FEnum.OptState.finished,
    resOptTime: new Date(),
    startTime: startTime,
    endTime: endTime
  }).save();
  return await transferState(doc._id, FEnum.DocumentState.lent);
};

exports.resBack = async (resUid, doc, lentBody) => {
  const { lentUid } = lentBody || {};
  const reqUser = await User.findById(lentUid);
  if (!reqUser) return false;
  await new DocLog({
    docId: doc._id,
    docName: doc.name,
    reqUid: reqUser._id,
    reqName: reqUser.name,
    resUid: resUid,
    resOptType: FEnum.ResOptType.back,
    resOptState: FEnum.OptState.finished,
    resOptTime: new Date()
  }).save();
  return await transferState(doc._id, FEnum.DocumentState.archived);
};

exports.resOptFuncDealtMap = {
  [FEnum.ResOptType.audit]: exports.resAudit,
  [FEnum.ResOptType.accept]: exports.resAccept,
  [FEnum.ResOptType.seal]: exports.resSeal,
  [FEnum.ResOptType.tax]: exports.resTax,
  [FEnum.ResOptType.archive]: exports.resArchive,
  [FEnum.ResOptType.lend]: exports.resLend,
  [FEnum.ResOptType.back]: exports.resBack,
  [FEnum.ResOptType.reject]: exports.resReject,
  [FEnum.ResOptType.deny]: exports.resDeny
};
