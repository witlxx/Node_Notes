"use strict";

const mongoose = require("mongoose");
const config = require(process.env.config);

/**连接数据库 */
mongoose.connect(
  config.mongo,
  {
    poolSize: 20,
    useCreateIndex: true,
    useNewUrlParser: true,
    useFindAndModify: false
  },
  function(err) {
    if (err) {
      process.exit(1);
    }
  }
);

require("../models/User");
require("../models/Department");
require("../models/ErrorLog");
require("../models/Document");
require("../models/DocumentLog");
require("../models/Rule");
require("../models/SystemSet");
require("../models/Tag");

/**实例化 */
exports.User = mongoose.model("User");
exports.Department = mongoose.model("Department");
exports.ErrorLog = mongoose.model("ErrorLog");
exports.Document = mongoose.model("Document");
exports.DocumentLog = mongoose.model("DocumentLog");
exports.Rule = mongoose.model("Rule");
exports.SystemSet = mongoose.model("SystemSet");
exports.Tag = mongoose.model("Tag");
