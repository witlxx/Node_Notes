"use strict";

const elasticsearch = require("elasticsearch");
const config = require(process.env.config);
const esClient = new elasticsearch.Client(config.es);

exports = module.exports = esClient;
