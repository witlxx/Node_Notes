"use strict";
const config = require(process.env.config);
const bcrypt = require("bcrypt");
const UUIDV4 = require("uuid/v4");
const ObjectId = require("mongoose").Types.ObjectId;
const { models: FModels, redis: RedisClient } = require("../connect");
const { FEnum } = require("../util");
const User = FModels.User;
const Dept = FModels.Department;

/**
 * 清库，不可以在beta或者生产环境使用
 */
exports.cleanMongo = async () => {
  if (process.env.NODE_ENV === "development") {
    await RedisClient.flushdb();
    await FModels.User.deleteMany({});
    await FModels.Department.deleteMany({});
    await FModels.Document.deleteMany({});
    await FModels.SystemSet.deleteMany({});
    await FModels.Rule.deleteMany({});
  }
};

exports.mockESDoc = name => {
  return { _id: ObjectId(), name: name || UUIDV4() };
};

exports.mockAdmin = async user => {
  user = user || {};
  user = exports.mockUser({
    deptId: user.deptId,
    isAdmin: true,
    email: user.email
  });
  return await new User(user).save();
};

exports.mockRule = rule => {
  rule = rule || {};
  return {
    name: rule.name || "test",
    category: rule.category || FEnum.DocumentCategory.incomeContract,
    auditPath: [
      { role: -1, level: config.rootDept.level + 3, roleName: "课长" },
      { role: -1, level: config.rootDept.level + 1, roleName: "中心长" },
      { role: -1, level: config.rootDept.level, roleName: "总经理" }
    ],
    sealPath: [
      { role: -1, level: config.rootDept.level + 3, roleName: "课长" },
      { role: -1, level: config.rootDept.level + 2, roleName: "部长" },
      { role: -1, level: config.rootDept.level + 1, roleName: "bsc中心长" },
      { role: FEnum.UserRole.sealer, level: null, roleNam: "bsc合同担当" }
    ]
  };
};

exports.mockUser = user => {
  user = user || {};
  return {
    name: user.name || "test",
    password: bcrypt.hashSync(user.password || "111111", 5),
    email:
      user.email ||
      Math.random()
        .toString(36)
        .substr(-7) + "@163.com",
    account:
      user.account ||
      Math.random()
        .toString(36)
        .substr(-7),
    deptId: user.deptId || new ObjectId(),
    isAdmin: user.isAdmin || false,
    isLeader: user.isLeader || false,
    roles: user.roles || [1],
    permissions: user.permissions || [1, 2, 3],
    status: user.status && FEnum.UserStatus.enable
  };
};

exports.mockDept = dept => {
  dept = dept || {};
  return {
    parentId: dept.parentId,
    name:
      dept.name ||
      Math.random()
        .toString(36)
        .substr(-7),
    referred:
      dept.referred ||
      Math.random()
        .toString(36)
        .substr(-7),
    level: dept.level || 1,
    isLeaf: dept.isLeaf && true,
    isSealDept: dept.isSealDept || false
  };
};

exports.mockDeptTrees = async () => {
  const dept1 = await new Dept(
    exports.mockDept({ name: "dept1", referred: "d1", level: 1, isLeaf: false })
  ).save();
  let depts2 = [],
    depts3 = [],
    depts4 = [];
  for (let i = 0; i < 5; i++) {
    depts2.push(
      exports.mockDept({
        name: "dept2" + UUIDV4(),
        referred: "d2" + UUIDV4(),
        parentId: dept1._id,
        level: 2,
        isLeaf: false
      })
    );
  }
  depts2 = await Dept.insertMany(depts2);
  const depts2Ids = depts2.map(dept2 => dept2._id);
  depts2Ids.forEach(deptId => {
    depts3.push(
      exports.mockDept({
        name: "dept3" + UUIDV4(),
        referred: "d3" + UUIDV4(),
        parentId: deptId,
        level: 3,
        isLeaf: false
      })
    );
  });
  depts3 = await Dept.insertMany(depts3);
  const dept3Ids = depts3.map(dept3 => dept3._id);
  dept3Ids.forEach(deptId => {
    depts4.push(
      exports.mockDept({
        name: "dept4" + UUIDV4(),
        referred: "d4" + UUIDV4(),
        parentId: deptId,
        level: 4
      })
    );
  });
  depts4 = await Dept.insertMany(depts4);
  const dept4Ids = depts4.map(dept4 => dept4._id);
  return [dept1._id, depts2Ids, dept3Ids, dept4Ids];
};

exports.mockSmbConfigure = smb => {
  smb = smb || {};
  return {
    setType: FEnum.SetType.storage,
    type: FEnum.StorageType.smb,
    content: {
      share: smb.share || "\\\\172.25.73.121\\web",
      domain: "WORKGROUP",
      username: smb.username || "gongjie",
      password: smb.password || "123456"
    }
  };
};

exports.mockDoc = doc => {
  doc = doc || {};
  return {
    name: doc.name || UUIDV4(),
    uid: doc.uid || ObjectId(),
    deptId: doc.deptId || ObjectId(),
    category: doc.category || FEnum.DocumentCategory.incomeContract,
    type: doc.type || FEnum.DocumentType.sale,
    startTime: new Date("2019-07-22T00:57:32.198Z"),
    endTime: new Date("2119-08-22T00:57:32.198Z"),
    contractMoney: doc.contractMoney || 0,
    currencyUnit: doc.currencyUnit || FEnum.CurrencyUnit.rmb,
    copies: 10,
    pages: 11,
    state: doc.state || FEnum.DocumentState.auditing,
    uploadPos: {
      storagePath: "../../test.js",
      fileName: "test.js"
    }
  };
};

exports.mockDocLog = docLog => {
  docLog = docLog || {};
  return {
    docId: docLog.docId || ObjectId(),
    docName: docLog.docName || "test",
    reqUid: docLog.reqUid || ObjectId(),
    reqName: docLog.reqName || "req",
    reqDeptId: docLog.reqDeptId || ObjectId(),
    resUid: docLog.resUid || ObjectId(),
    resDeptId: docLog.resDeptId || ObjectId(),
    resOptType: docLog.resOptType || FEnum.ResOptType.accept,
    resOptState: docLog.resOptState || FEnum.OptState.pending
  };
};
