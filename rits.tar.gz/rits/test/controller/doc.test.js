"use strict";
const app = require("../../app");
const config = require(process.env.config);
const jsonwebtoken = require("jsonwebtoken");
const request = require("supertest")(app.listen());
const should = require("should");
const FModels = require("../../connect/models");
const { Document: Doc, DocumentLog: DocLog } = FModels;
const { Rule, User, Department: Dept, SystemSet } = FModels;
const { FEnum } = require("../../util");
const { cleanMongo } = require("../mock");
const { mockAdmin, mockRule, mockDept, mockUser } = require("../mock");
const { mockDocLog, mockDoc, mockSmbConfigure } = require("../mock");

let admin, token;
afterEach(async () => {
  await cleanMongo();
});

beforeEach(async () => {
  const dept1 = await new Dept(mockDept({ level: 1, isLeaf: false })).save();
  const dept2 = await new Dept(
    mockDept({ level: 2, parentId: dept1._id, isLeaf: false })
  ).save();
  const bsc = await new Dept(
    mockDept({ level: 2, parentId: dept1._id, isLeaf: false, isSealDept: true })
  ).save();
  const bsc2 = await new Dept(
    mockDept({ level: 3, parentId: bsc._id, isLeaf: true, isSealDept: true })
  ).save();
  const dept3 = await new Dept(
    mockDept({ level: 3, parentId: dept2._id, isLeaf: false })
  ).save();
  await new Dept(mockDept({ level: 4, parentId: dept3._id })).save();
  await User.insertMany([
    mockUser({ isLeader: true, deptId: dept1._id }),
    mockUser({ isLeader: true, deptId: dept2._id }),
    mockUser({ name: "bsc中心长", isLeader: true, deptId: bsc._id }),
    mockUser({
      name: "审核者1",
      deptId: bsc2._id,
      roles: [FEnum.UserRole.sealer]
    }),
    mockUser({
      name: "审核者2",
      deptId: bsc2._id,
      roles: [FEnum.UserRole.sealer]
    }),
    mockUser({
      name: "审核者3",
      deptId: bsc2._id,
      roles: [FEnum.UserRole.sealer]
    }),
    mockUser({ isLeader: true, deptId: dept3._id })
  ]);

  admin = await mockAdmin({ deptId: dept3._id });
  token = jsonwebtoken.sign(
    { data: admin, exp: Math.floor(Date.now() / 1000) + 60 * 60 },
    config.aeskey.secret
  );
  await new Rule(mockRule()).save();
});

describe("test match rule", async () => {
  it("should success", async () => {
    const res = await request
      .post(`/doc/process`)
      .send({
        reqOptType: FEnum.ReqOptType.seal,
        documentCategory: FEnum.DocumentCategory.incomeContract,
        multiple: true
      })
      .set("token", token);
    should.exist(res.body.data);
  });
});

describe.skip("test download", async () => {
  let storage;
  beforeEach(async () => {
    await new SystemSet(mockSmbConfigure()).save();
    storage = await request
      .post("/doc/upload")
      .set("Content-Type", "multipart/form-data")
      .field("storage", FEnum.StorageType.smb)
      .field("documentCategory", FEnum.DocumentCategory.otherInstrument)
      .attach("file", __dirname + "/user.test.js")
      .set("token", token);
  });
  it("should success", async () => {
    const { storagePath } = storage.body.data;
    const res = await request
      .post("/doc/download")
      .send({ storagePath })
      .set("token", token);
    const buffer = res.body.data.buffer.data;
    should.exist(buffer);
  });
});

describe("GET /doc/:docId/records/:type", async () => {
  let docId;
  beforeEach(async () => {
    const doc = await new Doc(mockDoc()).save();
    docId = doc._id;
    await new DocLog(
      mockDocLog({
        docId,
        resOptState: FEnum.OptState.finished,
        resOptType: FEnum.ResOptType.lend
      })
    ).save();
  });
  it("should success", async () => {
    const res = await request
      .get(`/doc/${docId}/records/${FEnum.RecordType.lend}`)
      .set("token", token);
    should.exists(res.body.data);
    should.equal(Array.isArray(res.body.data), true);
  });
});

describe("POST /doc/:docId/:type", async () => {
  let docId, users;
  beforeEach(async () => {
    users = await User.insertMany([
      mockUser({ email: "Li.Xinxian@cn.ricoh.com" }),
      mockUser()
    ]);
    token = jsonwebtoken.sign(
      { data: users[1], exp: Math.floor(Date.now() / 1000) + 60 * 60 },
      config.aeskey.secret
    );
    await SystemSet.insertMany([
      {
        setType: FEnum.SetType.email,
        content: {
          host: "172.25.72.12",
          user: "",
          pass: "",
          port: 25,
          secure: "none",
          sender: "Gong.Jie@cn.ricoh.com"
        }
      }
    ]);
  });
  describe("test lend", async () => {
    beforeEach(async () => {
      const doc = await new Doc(
        mockDoc({ state: FEnum.DocumentState.archived })
      ).save();
      docId = doc._id;
    });
    it("should success", async () => {
      await request
        .post(`/doc/${docId}/${FEnum.ResOptType.lend}`)
        .send({
          lentBody: {
            lentUid: users[1]._id,
            startTime: new Date(),
            endTime: new Date()
          }
        })
        .set("token", token);
      const logs = await DocLog.find({ docId });
      should.equal(Array.isArray(logs), true);
      should.equal(logs.length, 1);
      should.equal(logs[0].reqName, users[1].name);
    });
  });
  describe("test audit", async () => {});
  describe("test accept", async () => {});
  describe("test seal", async () => {
    describe("test first one", async () => {
      beforeEach(async () => {
        const doc = await new Doc(
          mockDoc({ state: FEnum.DocumentState.sealing })
        ).save();
        docId = doc._id;
        await DocLog.insertMany([
          mockDocLog({
            docId: doc._id,
            reqUid: users[0]._id,
            resOptType: FEnum.ResOptType.accept,
            resOptState: FEnum.OptState.finished
          }),
          mockDocLog({
            docId: doc._id,
            reqUid: users[0]._id,
            resUid: users[1]._id,
            resOptType: FEnum.ResOptType.seal,
            resOptState: FEnum.OptState.dealing
          }),
          mockDocLog({
            docId: doc._id,
            reqUid: users[0]._id,
            resUid: users[0]._id,
            resOptType: FEnum.ResOptType.seal,
            resOptState: FEnum.OptState.pending
          })
        ]);
      });
      it("should success", async () => {
        await request
          .post(`/doc/${docId}/${FEnum.ResOptType.seal}`)
          .set("token", token);
        const logs = await DocLog.find({ docId });
        should.equal(Array.isArray(logs), true);
        should.equal(logs.length, 3);
        should.equal(logs[1].resOptState, FEnum.OptState.finished);
        should.equal(logs[2].resOptState, FEnum.OptState.dealing);
      });
    });
    describe("test last one", async () => {
      beforeEach(async () => {
        const doc = await new Doc(
          mockDoc({ state: FEnum.DocumentState.sealing })
        ).save();
        docId = doc._id;
        await DocLog.insertMany([
          mockDocLog({
            docId: doc._id,
            reqUid: users[0]._id,
            resOptType: FEnum.ResOptType.audit,
            resOptState: FEnum.OptState.finished
          }),
          mockDocLog({
            docId: doc._id,
            reqUid: users[0]._id,
            resOptType: FEnum.ResOptType.accept,
            resOptState: FEnum.OptState.finished
          }),
          mockDocLog({
            docId: doc._id,
            reqUid: users[0]._id,
            resUid: users[1]._id,
            resOptType: FEnum.ResOptType.seal,
            resOptState: FEnum.OptState.dealing
          })
        ]);
      });
      it("should success", async () => {
        await request
          .post(`/doc/${docId}/${FEnum.ResOptType.seal}`)
          .set("token", token);
        const logs = await DocLog.find({ docId });
        should.equal(Array.isArray(logs), true);
        should.equal(logs.length, 3);
      });
    });
  });
  describe("test tax", async () => {});
  describe("test archive", async () => {});
  describe("test back", async () => {});
  describe("test reject", async () => {});
  describe("test deny", async () => {
    beforeEach(async () => {
      const doc = await new Doc(
        mockDoc({ state: FEnum.DocumentState.auditing })
      ).save();
      docId = doc._id;
      await DocLog.insertMany([
        mockDocLog({
          docId: doc._id,
          reqUid: users[0]._id,
          resOptType: FEnum.ResOptType.audit,
          resOptState: FEnum.OptState.dealing
        }),
        mockDocLog({
          docId: doc._id,
          reqUid: users[0]._id,
          resUid: users[1]._id,
          resOptType: FEnum.ResOptType.audit,
          resOptState: FEnum.OptState.dealing
        }),
        mockDocLog({
          docId: doc._id,
          reqUid: users[0]._id,
          resOptType: FEnum.ResOptType.audit,
          resOptState: FEnum.OptState.dealing
        })
      ]);
    });
    it("should success", async () => {
      await request
        .post(`/doc/${docId}/${FEnum.ResOptType.deny}`)
        .set("token", token);
      const logs = await DocLog.find({ docId });
      should.equal(Array.isArray(logs), true);
      should.equal(logs.length, 3);
      should.equal(logs[0].status, false);
      should.equal(logs[1].status, false);
      should.equal(logs[2].status, false);
    });
  });
});
