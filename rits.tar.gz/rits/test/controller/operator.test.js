"use strict";

"use strict";
const app = require("../../app");
const request = require("supertest")(app.listen());
const should = require("should");
const config = require(process.env.config);
const jsonwebtoken = require("jsonwebtoken");
const expect = require("chai").expect;
const FError = require("../../util/FError");
const FModels = require("../../connect").models;
const { FEnum } = require("../../util");
const { Department: Dept, User } = FModels;
const { cleanMongo } = require("../mock");
const { mockUser, mockAdmin, mockDept } = require("../mock");

let admin, token;
afterEach(async () => {
  await cleanMongo();
});

beforeEach(async () => {
  admin = await mockAdmin();
  token = jsonwebtoken.sign(
    { data: admin, exp: Math.floor(Date.now() / 1000) + 60 * 60 },
    config.aeskey.secret
  );
});

describe("test POST /", async () => {
  let user;
  beforeEach(async () => {
    let dept = await new Dept(mockDept()).save();
    user = mockUser({ deptId: dept._id });
  });
  describe("noraml functions", async () => {
    it("should success", async () => {
      const res = await request
        .post("/operator/")
        .send(user)
        .set(`token`, `${token}`)
        .expect(201);
      should.exist(res.body);
      should.equal(res.body.errorCode, 0);
    });
  });
  describe("dismatch roles and accesses", async () => {
    it("should success", async () => {
      user.permissions = [4, 5, 6];
      const res = await request
        .post("/operator/")
        .send(user)
        .set(`token`, `${token}`)
        .expect(400);
      should.exist(res.body);
      should.equal(FError.isTypeOf(res.body, FError.AuthenticationRole), true);
    });
  });
  describe("dismatch roles and accesses", async () => {
    let user2;
    beforeEach(async () => {
      user2 = await new User(mockUser()).save();
    });
    it("should success", async () => {
      user.account = user2.account;
      const res = await request
        .post("/operator/")
        .send(user)
        .set(`token`, `${token}`)
        .expect(403);
      should.exist(res.body);
      should.equal(FError.isTypeOf(res.body, FError.UserHasExist), true);
    });
  });
  describe("if status disabled", async () => {
    let user2;
    beforeEach(async () => {
      user2 = await new User(
        mockUser({ status: FEnum.UserStatus.disable })
      ).save();
    });
    it("should success", async () => {
      user.account = user2.account;
      const res = await request
        .post("/operator/")
        .send(user)
        .set(`token`, `${token}`)
        .expect(201);
      should.exist(res.body);
      should.equal(res.body.errorCode, 0);
    });
  });
});

describe("test PUT /:suid", async () => {
  let user2, suid, user;
  beforeEach(async () => {
    let dept = await new Dept(mockDept()).save();
    user = mockUser({ deptId: dept._id });
    user2 = await new User(mockUser()).save();
  });
  describe("test normal", async () => {
    it("should success", async () => {
      suid = user2._id;
      user.account = user2.account;
      await request
        .put(`/operator/${suid}`)
        .send(user)
        .set(`token`, `${token}`)
        .expect(204);
    });
  });
});

describe("test DELETE /:suid", async () => {
  let user2, suid, user;
  beforeEach(async () => {
    let dept = await new Dept(mockDept()).save();
    user = mockUser({ deptId: dept._id });
    user2 = await new User(mockUser()).save();
  });
  describe("test normal function", async () => {
    it("should success", async () => {
      suid = user2._id;
      user.account = user2.account;
      await request
        .delete(`/operator/${suid}`)
        .send(user)
        .set(`token`, `${token}`)
        .expect(204);
      const user4 = await User.findById(suid);
      should.equal(user4.status, FEnum.UserStatus.disable);
    });
  });
});

describe("test GET /count", async () => {
  let users = [];
  beforeEach(async () => {
    for (let i = 0; i < 25; i++) {
      users.push(mockUser());
    }
    await User.insertMany(users);
  });
  it("should success", async () => {
    const res = await request
      .get(`/operator/count?uid=${admin._id}`)
      .set(`token`, `${token}`)
      .expect(200);
    should.exist(res.body.data.count);
  });
});

describe("test GET /", async () => {
  let users = [];
  beforeEach(async () => {
    for (let i = 0; i < 25; i++) {
      users.push(mockUser());
    }
    await User.insertMany(users);
  });
  it("should success", async () => {
    const res = await request
      .get(`/operator?uid=${admin._id}&page=0&count=2`)
      .set(`token`, `${token}`)
      .expect(200);
    should.equal(Array.isArray(res.body.data), true);
    should.equal(res.body.data.length, 2);
  });
});
