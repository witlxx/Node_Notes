"use strict";
const app = require("../../app");
const config = require(process.env.config);
const jsonwebtoken = require("jsonwebtoken");
const request = require("supertest")(app.listen());
const should = require("should");
const FModels = require("../../connect/models");
const { Department: Dept } = FModels;
const { cleanMongo } = require("../mock");
const { mockDept, mockAdmin } = require("../mock");

let admin, token;
afterEach(async () => {
  await cleanMongo();
});

beforeEach(async () => {
  let depts = [];
  admin = await mockAdmin();
  token = jsonwebtoken.sign(
    { data: admin, exp: Math.floor(Date.now() / 1000) + 60 * 60 },
    config.aeskey.secret
  );
  for (let i = 0; i < 51; i++) {
    depts.push(mockDept({}));
  }
  for (let i = 0; i < 50; i++) {
    depts.push(
      mockDept({
        name: "niho" + Math.random()
      })
    );
  }
  await Dept.insertMany(depts);
});

describe("test fuzzy search", async () => {
  it("should success", async () => {
    const res = await request
      .get(`/dept/count?keyword=niho`)
      .set(`token`, `${token}`);
    should.equal(res.body.data.count, 50);
  });
});

describe("test fuzzy search", async () => {
  it("should success", async () => {
    const res = await request
      .get(`/dept?keyword=niho&count=30`)
      .set(`token`, `${token}`);
    should.equal(Array.isArray(res.body.data), true);
    should.equal(res.body.data.length, 30);
  });
});
