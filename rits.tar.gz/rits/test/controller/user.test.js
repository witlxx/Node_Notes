"use strict";
const app = require("../../app");
const request = require("supertest")(app.listen());
const should = require("should");
const mock = require("../mock");
const FModels = require("../../connect/models");
const config = require(process.env.config);
const jsonwebtoken = require("jsonwebtoken");
const { FEnum } = require("../../util");
const expect = require("chai").expect;
const User = FModels.User;
const SystemSet = FModels.SystemSet;

let user;
afterEach(async () => {
  await mock.cleanMongo();
});

describe("test user controller", async () => {
  beforeEach(async () => {
    user = await new User(
      await mock.mockUser({ email: "Li.Xinxian@cn.ricoh.com" })
    ).save();
    await SystemSet.insertMany([
      {
        setType: FEnum.SetType.email,
        content: {
          host: "172.25.72.12",
          user: "",
          pass: "",
          port: 25,
          secure: "none",
          sender: "Gong.Jie@cn.ricoh.com"
        }
      },
      {
        setType: FEnum.SetType.storage,
        type: FEnum.StorageType.smb,
        content: {
          share: "\\\\172.25.73.121\\web",
          domain: "WORKGROUP",
          username: "gongjie",
          password: "123456"
        }
      }
    ]);
  });

  describe("GET /user/agents", async () => {
    let user, token;
    beforeEach(async () => {
      const depts = await mock.mockDeptTrees();
      const deptId = depts[3][1];
      user = await mock.mockAdmin({ deptId: deptId });
      token = jsonwebtoken.sign(
        { data: user, exp: Math.floor(Date.now() / 1000) + 60 * 60 },
        config.aeskey.secret
      );
    });
    it("should success", async () => {
      const res = await request.get(`/user/agents`).set(`token`, `${token}`);
      should.exist(res.body.data);
      should.equal(Array.isArray(res.body.data), true);
    });
  });

  describe("POST /user/login", async () => {
    let user,
      password = "111111";
    beforeEach(async () => {
      user = await new User(await mock.mockUser({ password })).save();
    });
    it("should success", async () => {
      const res = await request
        .post(`/user/login`)
        .send({ password, account: user.account })
        .expect(200);
      should.exist(res.body);
      should.equal(res.body.data.account, user.account);
    });
  });

  describe("POST /user/pass", async () => {
    describe.skip("test sendEmail", async () => {
      it("should success", async () => {
        await request
          .post("/user/pass")
          .send({
            email: user.email,
            account: user.account
          })
          .expect(201);
      });
    });
  });

  describe("PUT /user/passwd", async () => {
    let user,
      token,
      password = "111111";
    beforeEach(async () => {
      user = await new User(await mock.mockUser({ password })).save();
      token = jsonwebtoken.sign(
        { data: user, exp: Math.floor(Date.now() / 1000) + 60 * 60 },
        config.aeskey.secret
      );
    });
    it("should success", async () => {
      await request
        .put("/user/passwd")
        .send({
          account: user.account,
          email: user.email,
          type: FEnum.PassUpdMethod.reset,
          newPass: "123456",
          repeatPass: "123456",
          originPass: "111111"
        })
        .set(`token`, `${token}`)
        .expect(204);
    });
  });

  describe.skip("POST /user/avatar", async () => {
    let user,
      token,
      password = "111111";
    beforeEach(async () => {
      user = await new User(await mock.mockUser({ password })).save();
      token = jsonwebtoken.sign(
        { data: user, exp: Math.floor(Date.now() / 1000) + 60 * 60 },
        config.aeskey.secret
      );
    });
    it("should success", async () => {
      const res = await request
        .post("/user/avatar")
        .field("storage", FEnum.StorageType.smb)
        .attach("file", __dirname + "/user.test.js")
        .set("token", token);
      should.exist(res.body);
    });
  });

  describe("GET /user/", async () => {
    let user,
      token,
      password = "111111";
    beforeEach(async () => {
      user = await new User(await mock.mockUser({ password })).save();
      token = jsonwebtoken.sign(
        { data: user, exp: Math.floor(Date.now() / 1000) + 60 * 60 },
        config.aeskey.secret
      );
      await request
        .post("/user/avatar")
        .field("storage", FEnum.StorageType.smb)
        .attach("file", __dirname + "/user.test.js")
        .set("token", token);
    });
    it("should success", async () => {
      const res = await request.get("/user/").set("token", token);
      should.exist(res.body);
      should.equal(res.body.data._id, user._id);
    });
  });
});
