"use strict";
const UUIDV4 = require("uuid/v4");
const ObjectId = require("mongoose").Types.ObjectId;
const should = require("should");
const proxy = require("../../proxy");
const docProxy = proxy.docProxy;
const config = require(process.env.config);
const esClient = require("../../connect").elastic;
const FModels = require("../../connect").models;
const { SystemSet: System, Document: Doc, DocumentLog: DocLog } = FModels;
const { FEnum } = require("../../util");
const { cleanMongo } = require("../mock");
const { mockSmbConfigure, mockESDoc, mockDoc, mockDocLog } = require("../mock");

const storageBody = {
  uid: UUIDV4(),
  storage: FEnum.StorageType.smb,
  dir: FEnum.StorageDirType.avatars,
  path: __dirname + "/user.test.js",
  name: "user.test.js"
};

afterEach(async () => {
  await cleanMongo();
});

describe("test doc", async () => {
  describe("test indexESDoc", async () => {
    let doc = {};
    beforeEach(async () => {
      doc = mockESDoc("ok");
    });
    it("should success", async () => {
      await docProxy.indexESDoc(config.docESIndex, doc);
      const res = await esClient.count({ index: config.docESIndex });
      should.exist(res.count);
    });
  });

  describe("test storeFile", async () => {
    describe("test if no smb configure", async () => {
      it("should failed", async () => {
        const res = await docProxy.storeFile(storageBody);
        should.equal(res, false);
      });
    });

    describe("test if smb exists", async () => {
      beforeEach(async () => {
        await new System(mockSmbConfigure()).save();
      });
      it("should success", async () => {
        const res = await docProxy.storeFile(storageBody);
        should.exist(res);
      });
    });
  });

  describe.skip("test acquireFile", async () => {
    let files;
    beforeEach(async () => {
      await new System(mockSmbConfigure()).save();
      files = await docProxy.storeFile(storageBody);
    });
    const fs = require("fs");
    it("should success", async () => {
      const res = await docProxy.acquireFile(files);
      fs.writeFileSync(__dirname + "123.jpeg", res.buffer);
    });
  });

  describe("test countDocs", async () => {
    beforeEach(async () => {
      let docs = [];
      for (let i = 0; i < 10; i++) {
        let contractMoney = Math.random() * 100;
        let currencyUnit = Math.ceil(Math.random() * 3);
        let name =
          "测试" +
          Math.random()
            .toString(36)
            .substr(-6);
        docs.push(mockDoc({ name, contractMoney, currencyUnit }));
      }
      docs = await Doc.insertMany(docs);
      const promises = [];
      docs.forEach(doc =>
        promises.push(docProxy.indexESDoc(config.docESIndex, doc))
      );
      await Promise.all(docs);
    });
    it("should success", async () => {
      const result = await docProxy.countDocs({
        startTime: "2019-07-22 09:59:36",
        endTime: "2119-09-22 09:59:36",
        category: 1,
        type: 12,
        keyword: "测试"
      });
      should.exists(result.details);
      should.equal(Array.isArray(result.details), true);
    });
  });

  describe("test acquireDealtDocs and ", async () => {
    /**生成3个文件,一个该我审批,一个该我盖章 */
    let uid = ObjectId();
    beforeEach(async () => {
      const doc1 = await new Doc(mockDoc({ name: "测试1" })).save();
      const doc2 = await new Doc(mockDoc({ name: "测试2" })).save();
      const doc3 = await new Doc(mockDoc({ name: "测试3" })).save();
      const logs = [
        mockDocLog({
          docId: doc1._id,
          resUid: uid,
          resOptType: FEnum.ResOptType.audit,
          resOptState: FEnum.OptState.dealing
        }),
        mockDocLog({
          docId: doc2._id,
          resUid: uid,
          resOptType: FEnum.ResOptType.seal,
          resOptState: FEnum.OptState.dealing
        }),
        mockDocLog({
          docId: doc3._id,
          resUid: uid,
          resOptType: FEnum.ResOptType.audit,
          resOptState: FEnum.OptState.pending
        })
      ];
      await DocLog.insertMany(logs);
    });
    it("should success", async () => {
      const result = await docProxy.acquireDealtDocs(uid, { type: 12 });
      should.exist(result);
      should.equal(Array.isArray(result), true);
      should.equal(result.length, 2);
    });

    it("should success", async () => {
      const result = await docProxy.countDealtDocs(uid, { type: 12 });
      should.exist(result);
      should.equal(result.totalCount, 2);
    });
  });
});
