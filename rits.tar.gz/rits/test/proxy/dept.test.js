"use strict";
const ObjectId = require("mongoose").Types.ObjectId;
const should = require("should");
const proxy = require("../../proxy");
const deptProxy = proxy.deptProxy;
const FModels = require("../../connect/models");
const Dept = FModels.Department;
const { mockDept, cleanMongo, mockDeptTrees } = require("../mock");
const config = require(process.env.config);

afterEach(async () => {
  await cleanMongo();
});

describe("test createDept", async () => {
  let parentId, patrLevel;
  beforeEach(async () => {
    const patr = await new Dept(
      mockDept({ name: "test", referred: "te", level: 10 })
    ).save();
    patrLevel = patr.level;
    parentId = patr._id;
  });
  it("should success", async () => {
    const dept = await deptProxy.createDept(mockDept());
    should.exist(dept);
    should.equal(dept.level, config.rootDept.level);
  });
  it("should failed", async () => {
    const dept = await deptProxy.createDept(
      mockDept({ parentId: new ObjectId() })
    );
    should.equal(dept, false);
  });
  it("should success", async () => {
    const dept = await deptProxy.createDept(mockDept({ parentId: parentId }));
    should.equal(dept.level, patrLevel + 1);
  });
});

describe("test updateDept", async () => {
  let parentId, patrLevel, curDeptId;
  let dpetId = new ObjectId();
  beforeEach(async () => {
    const patr = await new Dept(
      mockDept({ name: "test", referred: "te", level: 10 })
    ).save();
    patrLevel = patr.level;
    parentId = patr._id;
    const patr2 = await new Dept(
      mockDept({ name: "test2", referred: "te2", level: 11 })
    ).save();
    const subDept = await new Dept(
      mockDept({
        name: "subTest",
        referred: "sub",
        level: 12,
        parentId: patr2._id
      })
    ).save();
    curDeptId = subDept._id;
  });
  it("not exists deptId", async () => {
    const dept = await deptProxy.updateDept(dpetId, mockDept());
    should.not.exist(dept);
  });
  it("change name", async () => {
    await deptProxy.updateDept(parentId, mockDept({ name: "test111" }));
    const curDept = await Dept.findById(parentId);
    should.equal(curDept.name, "test111");
  });
  /**从patr部门改到patr1部门,职级由12变为11 */
  it("change patr department", async () => {
    await deptProxy.updateDept(curDeptId, mockDept({ parentId: parentId }));
    const curDept = await Dept.findById(curDeptId);
    should.equal(curDept.level, patrLevel + 1);
  });
});

describe("test getPatrDept", async () => {
  let treeList = [];
  beforeEach(async () => {
    treeList = await mockDeptTrees();
  });
  it("should success", async () => {
    const deptId = treeList[3][2];
    const patr5 = await deptProxy.getPatrDept(deptId, 5);
    const patr4 = await deptProxy.getPatrDept(deptId, 4);
    const patr3 = await deptProxy.getPatrDept(deptId, 3);
    const patr2 = await deptProxy.getPatrDept(deptId, 2);
    const patr1 = await deptProxy.getPatrDept(deptId, 1);
    should.equal(patr5.level, 4);
    should.equal(patr4.level, 4);
    should.equal(patr3.level, 3);
    should.equal(patr2.level, 2);
    should.equal(patr1.level, 1);
    should.equal(patr1._id.toString(), treeList[0]);
  });
});

describe("test getKinDeptIds", async () => {
  let treeList = [];
  beforeEach(async () => {
    treeList = await mockDeptTrees();
  });
  it("should success", async () => {
    const deptId = treeList[0];
    const depts = await deptProxy.getKinDeptIds(deptId);
    should.equal(depts.length, 16);
    const dept2Id = treeList[1][1];
    const dept2s = await deptProxy.getKinDeptIds(dept2Id);
    should.equal(dept2s.length, 3);
    const dept3Id = treeList[2][1];
    const dept3s = await deptProxy.getKinDeptIds(dept3Id);
    should.equal(dept3s.length, 2);
    const dept4Id = treeList[3][1];
    const dept4s = await deptProxy.getKinDeptIds(dept4Id);
    should.equal(dept4s[0].toString(), dept4Id);
  });
});
