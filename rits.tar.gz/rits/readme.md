### 目录结构和功能用法

bin 可执行文件  
 config 配置文件  
 connect 连接管理文件  
 controller 业务文件  
 middlewares 中间件  
 models 数据库模型定义文件  
 netSchemas 输入参数校验文件  
 proxy 数据库功能文件  
 routes 路由文件  
 test 单元测试文件  
 util 共用函数文件  
 app.js 项目入口

#### controller 业务层

deptController 部门业务  
 docController 文档业务  
 ruleController 规则业务  
 systemController 系统设定业务  
 userController 用户业务

#### proxy 功能层

deptProxy 部门功能  
 docProxy 文档功能  
 processProxy 文档处理流程功能  
 ruleProxy 规则部门功能  
 smbProxy smb 存储部分功能  
 systemProxy 系统设定部分功能  
 userProxy 用户部分功能

---

### 本地起服务操作步骤

#### 创建 mongo 映射的数据卷文件夹

&ensp;sudo mkdir -p /opt/docmongodb/data/db  
 &ensp;sudo chmod 777 /opt/docmongodb/data/db

#### 安装第三方模块

&ensp;yarn install(或 npm install --registry=http://registry.npm.taobao.org)

#### 生成配置

&ensp;sudo mkdir config  
 &ensp;cp ./config.default.js ./config/config.js

#### 修改配置(配置本地 mongo/redis/es 账号)

#### 起服务

&ensp;sudo docker-compose up -d
